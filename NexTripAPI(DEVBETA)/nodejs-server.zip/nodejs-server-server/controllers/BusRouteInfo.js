'use strict';

var url = require('url');

var BusRouteInfo = require('./BusRouteInfoService');

module.exports.updateroute = function updateroute (req, res, next) {
  BusRouteInfo.updateroute(req.swagger.params, res, next);
};
