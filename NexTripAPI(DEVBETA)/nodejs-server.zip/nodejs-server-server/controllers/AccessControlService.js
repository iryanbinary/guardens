'use strict';

exports.getAuthCode = function(args, res, next) {
  /**
   * Request a temporary code for the desired API Access Token Scope(s)
   *
   * grant_type String value = authorization_code
   * client_id String a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
   * redirect_uri String App Callback URI
   * returns success
   **/
  var examples = {};
  examples['application/json'] = {
  "code" : 0,
  "message" : "aeiou",
  "fields" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getTokenRequest = function(args, res, next) {
  /**
   * Applications request an implicit token with a client id and secret prior to user authentication
   *
   * grant_type String value = implicit
   * client_id String a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
   * client_secret String the client secret associated to the app client id (this changes with each app store version iteration)
   * returns OAuth_Token
   **/
  var examples = {};
  examples['application/json'] = {
  "refresh_token" : "aeiou",
  "scopes" : "aeiou",
  "token_type" : "aeiou",
  "expires_in" : "aeiou",
  "token" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.postTokenRequest = function(args, res, next) {
  /**
   * Authorization Code grant types require a POST to the token endpoint after a GET for Authorization code.
   *
   * returns OAuth_Token
   **/
  var examples = {};
  examples['application/json'] = {
  "refresh_token" : "aeiou",
  "scopes" : "aeiou",
  "token_type" : "aeiou",
  "expires_in" : "aeiou",
  "token" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

