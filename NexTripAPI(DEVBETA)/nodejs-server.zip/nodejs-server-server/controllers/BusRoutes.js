'use strict';

var url = require('url');

var BusRoutes = require('./BusRoutesService');

module.exports.getDepartures = function getDepartures (req, res, next) {
  BusRoutes.getDepartures(req.swagger.params, res, next);
};

module.exports.getDirections = function getDirections (req, res, next) {
  BusRoutes.getDirections(req.swagger.params, res, next);
};

module.exports.getProviders = function getProviders (req, res, next) {
  BusRoutes.getProviders(req.swagger.params, res, next);
};

module.exports.getRoutes = function getRoutes (req, res, next) {
  BusRoutes.getRoutes(req.swagger.params, res, next);
};

module.exports.getStops = function getStops (req, res, next) {
  BusRoutes.getStops(req.swagger.params, res, next);
};

module.exports.getTimepointDepartures = function getTimepointDepartures (req, res, next) {
  BusRoutes.getTimepointDepartures(req.swagger.params, res, next);
};

module.exports.getVehicleLocations = function getVehicleLocations (req, res, next) {
  BusRoutes.getVehicleLocations(req.swagger.params, res, next);
};
