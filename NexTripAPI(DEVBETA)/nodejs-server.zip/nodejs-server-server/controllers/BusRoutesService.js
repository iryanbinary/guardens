'use strict';

exports.getDepartures = function(args, res, next) {
  /**
   * Returns a list of departures scheduled for any given bus stop.
   *
   * sTOPID String Specify the value of the Bus Stop ID as an abbreviated string
   * returns success
   **/
  var examples = {};
  examples['application/json'] = {
  "code" : 0,
  "message" : "aeiou",
  "fields" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getDirections = function(args, res, next) {
  /**
   * Returns the two directions that are valid for a given route.
   *
   * rOUTE Integer Sepcify the Route ID as an integer.
   * returns success
   **/
  var examples = {};
  examples['application/json'] = {
  "code" : 0,
  "message" : "aeiou",
  "fields" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getProviders = function(args, res, next) {
  /**
   * Returns a list of area Transit providers.  Providers are identified in the list of Routes allowing routes to be selected for a single provider. 
   *
   * returns success
   **/
  var examples = {};
  examples['application/json'] = {
  "code" : 0,
  "message" : "aeiou",
  "fields" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getRoutes = function(args, res, next) {
  /**
   * Returns a list of Transit routes that are in service on the current day.
   *
   * returns RouteData
   **/
  var examples = {};
  examples['application/json'] = {
  "ProviderID" : 1,
  "code" : 0,
  "Description" : "aeiou",
  "Route" : 6
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getStops = function(args, res, next) {
  /**
   * Returns a list of Timepoint stops for the given Route/Direction.
   *
   * rOUTE Integer Sepcify the Route ID as an integer.
   * dIRECTION Integer Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)
   * returns success
   **/
  var examples = {};
  examples['application/json'] = {
  "code" : 0,
  "message" : "aeiou",
  "fields" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getTimepointDepartures = function(args, res, next) {
  /**
   * Returns the scheduled departures for a selected route, direction and timepoint stop.
   *
   * rOUTE Integer Sepcify the Route ID as an integer.
   * dIRECTION Integer Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)
   * sTOP String Specify the value of the Bus Stop ID as an abbreviated string
   * returns TimePoints
   **/
  var examples = {};
  examples['application/json'] = {
  "DepartureText" : "aeiou",
  "DepartureTime" : "aeiou",
  "RouteDirection" : "aeiou",
  "code" : 0,
  "Description" : "aeiou",
  "Gate" : "aeiou",
  "Terminal" : "aeiou",
  "VehicleLongitude" : "aeiou",
  "VehicleLatitude" : "aeiou",
  "Actual" : true,
  "BlockNumber" : 6,
  "Route" : 1,
  "VehicleHeading" : 5
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getVehicleLocations = function(args, res, next) {
  /**
   * This operation returns a list of vehicles currently in service that have recently (within 5 minutes)  reported their locations. A route paramter is used to return results for the given route.  Use \"0\" for the route parameter to return a list of all vehicles in service.
   *
   * rOUTE Integer Sepcify the Route ID as an integer.
   * returns success
   **/
  var examples = {};
  examples['application/json'] = {
  "code" : 0,
  "message" : "aeiou",
  "fields" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

