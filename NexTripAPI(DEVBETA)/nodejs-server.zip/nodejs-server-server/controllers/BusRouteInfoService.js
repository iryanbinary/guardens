'use strict';

exports.updateroute = function(args, res, next) {
  /**
   * Update a bus route
   *
   * rOUTE Integer Sepcify the Route ID as an integer.
   * returns RouteData
   **/
  var examples = {};
  examples['application/json'] = {
  "ProviderID" : 1,
  "code" : 0,
  "Description" : "aeiou",
  "Route" : 6
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

