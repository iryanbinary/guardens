'use strict';

var url = require('url');

var AccessControl = require('./AccessControlService');

module.exports.getAuthCode = function getAuthCode (req, res, next) {
  AccessControl.getAuthCode(req.swagger.params, res, next);
};

module.exports.getTokenRequest = function getTokenRequest (req, res, next) {
  AccessControl.getTokenRequest(req.swagger.params, res, next);
};

module.exports.postTokenRequest = function postTokenRequest (req, res, next) {
  AccessControl.postTokenRequest(req.swagger.params, res, next);
};
