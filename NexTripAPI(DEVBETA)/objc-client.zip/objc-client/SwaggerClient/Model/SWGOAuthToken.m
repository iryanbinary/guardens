#import "SWGOAuthToken.h"

@implementation SWGOAuthToken

- (instancetype)init {
  self = [super init];
  if (self) {
    // initialize property's default value, if any
    
  }
  return self;
}


/**
 * Maps json key to property name.
 * This method is used by `JSONModel`.
 */
+ (JSONKeyMapper *)keyMapper {
  return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{ @"token": @"token", @"refreshToken": @"refresh_token", @"tokenType": @"token_type", @"expiresIn": @"expires_in", @"scopes": @"scopes" }];
}

/**
 * Indicates whether the property with the given name is optional.
 * If `propertyName` is optional, then return `YES`, otherwise return `NO`.
 * This method is used by `JSONModel`.
 */
+ (BOOL)propertyIsOptional:(NSString *)propertyName {

  NSArray *optionalProperties = @[@"token", @"refreshToken", @"tokenType", @"expiresIn", @"scopes"];
  return [optionalProperties containsObject:propertyName];
}

@end
