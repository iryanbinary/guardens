#import "SWGTimePoints.h"

@implementation SWGTimePoints

- (instancetype)init {
  self = [super init];
  if (self) {
    // initialize property's default value, if any
    
  }
  return self;
}


/**
 * Maps json key to property name.
 * This method is used by `JSONModel`.
 */
+ (JSONKeyMapper *)keyMapper {
  return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{ @"code": @"code", @"actual": @"Actual", @"blockNumber": @"BlockNumber", @"departureText": @"DepartureText", @"departureTime": @"DepartureTime", @"_description": @"Description", @"gate": @"Gate", @"route": @"Route", @"routeDirection": @"RouteDirection", @"terminal": @"Terminal", @"vehicleHeading": @"VehicleHeading", @"vehicleLatitude": @"VehicleLatitude", @"vehicleLongitude": @"VehicleLongitude" }];
}

/**
 * Indicates whether the property with the given name is optional.
 * If `propertyName` is optional, then return `YES`, otherwise return `NO`.
 * This method is used by `JSONModel`.
 */
+ (BOOL)propertyIsOptional:(NSString *)propertyName {

  NSArray *optionalProperties = @[@"code", @"actual", @"blockNumber", @"departureText", @"departureTime", @"_description", @"gate", @"route", @"routeDirection", @"terminal", @"vehicleHeading", @"vehicleLatitude", @"vehicleLongitude"];
  return [optionalProperties containsObject:propertyName];
}

@end
