# SWGBusRoutesApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getDepartures**](SWGBusRoutesApi.md#getdepartures) | **GET** /NexTrip/{STOPID} | 
[**getDirections**](SWGBusRoutesApi.md#getdirections) | **GET** /NexTrip/Directions/{ROUTE} | 
[**getProviders**](SWGBusRoutesApi.md#getproviders) | **GET** /NexTrip/Providers | 
[**getRoutes**](SWGBusRoutesApi.md#getroutes) | **GET** /NexTrip/Routes | 
[**getStops**](SWGBusRoutesApi.md#getstops) | **GET** /NexTrip/Stops/{ROUTE}/{DIRECTION} | 
[**getTimepointDepartures**](SWGBusRoutesApi.md#gettimepointdepartures) | **GET** /NexTrip/{ROUTE}/{DIRECTION}/{STOP} | 
[**getVehicleLocations**](SWGBusRoutesApi.md#getvehiclelocations) | **GET** /NexTrip/VehicleLocations/{ROUTE} | 


# **getDepartures**
```objc
-(NSURLSessionTask*) getDeparturesWithSTOPID: (NSString*) sTOPID
        completionHandler: (void (^)(SWGSuccess* output, NSError* error)) handler;
```



Returns a list of departures scheduled for any given bus stop.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sTOPID = @"sTOPID_example"; // Specify the value of the Bus Stop ID as an abbreviated string

SWGBusRoutesApi*apiInstance = [[SWGBusRoutesApi alloc] init];

[apiInstance getDeparturesWithSTOPID:sTOPID
          completionHandler: ^(SWGSuccess* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBusRoutesApi->getDepartures: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sTOPID** | **NSString***| Specify the value of the Bus Stop ID as an abbreviated string | 

### Return type

[**SWGSuccess***](SWGSuccess.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getDirections**
```objc
-(NSURLSessionTask*) getDirectionsWithROUTE: (NSNumber*) rOUTE
        completionHandler: (void (^)(SWGSuccess* output, NSError* error)) handler;
```



Returns the two directions that are valid for a given route.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* rOUTE = @56; // Sepcify the Route ID as an integer.

SWGBusRoutesApi*apiInstance = [[SWGBusRoutesApi alloc] init];

[apiInstance getDirectionsWithROUTE:rOUTE
          completionHandler: ^(SWGSuccess* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBusRoutesApi->getDirections: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rOUTE** | **NSNumber***| Sepcify the Route ID as an integer. | 

### Return type

[**SWGSuccess***](SWGSuccess.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getProviders**
```objc
-(NSURLSessionTask*) getProvidersWithCompletionHandler: 
        (void (^)(SWGSuccess* output, NSError* error)) handler;
```



Returns a list of area Transit providers.  Providers are identified in the list of Routes allowing routes to be selected for a single provider. 

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];



SWGBusRoutesApi*apiInstance = [[SWGBusRoutesApi alloc] init];

[apiInstance getProvidersWithCompletionHandler: 
          ^(SWGSuccess* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBusRoutesApi->getProviders: %@", error);
                        }
                    }];
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SWGSuccess***](SWGSuccess.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getRoutes**
```objc
-(NSURLSessionTask*) getRoutesWithCompletionHandler: 
        (void (^)(SWGRouteData* output, NSError* error)) handler;
```



Returns a list of Transit routes that are in service on the current day.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];



SWGBusRoutesApi*apiInstance = [[SWGBusRoutesApi alloc] init];

[apiInstance getRoutesWithCompletionHandler: 
          ^(SWGRouteData* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBusRoutesApi->getRoutes: %@", error);
                        }
                    }];
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SWGRouteData***](SWGRouteData.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getStops**
```objc
-(NSURLSessionTask*) getStopsWithROUTE: (NSNumber*) rOUTE
    dIRECTION: (NSNumber*) dIRECTION
        completionHandler: (void (^)(SWGSuccess* output, NSError* error)) handler;
```



Returns a list of Timepoint stops for the given Route/Direction.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* rOUTE = @56; // Sepcify the Route ID as an integer.
NSNumber* dIRECTION = @56; // Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)

SWGBusRoutesApi*apiInstance = [[SWGBusRoutesApi alloc] init];

[apiInstance getStopsWithROUTE:rOUTE
              dIRECTION:dIRECTION
          completionHandler: ^(SWGSuccess* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBusRoutesApi->getStops: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rOUTE** | **NSNumber***| Sepcify the Route ID as an integer. | 
 **dIRECTION** | **NSNumber***| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) | 

### Return type

[**SWGSuccess***](SWGSuccess.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getTimepointDepartures**
```objc
-(NSURLSessionTask*) getTimepointDeparturesWithROUTE: (NSNumber*) rOUTE
    dIRECTION: (NSNumber*) dIRECTION
    sTOP: (NSString*) sTOP
        completionHandler: (void (^)(SWGTimePoints* output, NSError* error)) handler;
```



Returns the scheduled departures for a selected route, direction and timepoint stop.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* rOUTE = @56; // Sepcify the Route ID as an integer.
NSNumber* dIRECTION = @56; // Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)
NSString* sTOP = @"sTOP_example"; // Specify the value of the Bus Stop ID as an abbreviated string

SWGBusRoutesApi*apiInstance = [[SWGBusRoutesApi alloc] init];

[apiInstance getTimepointDeparturesWithROUTE:rOUTE
              dIRECTION:dIRECTION
              sTOP:sTOP
          completionHandler: ^(SWGTimePoints* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBusRoutesApi->getTimepointDepartures: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rOUTE** | **NSNumber***| Sepcify the Route ID as an integer. | 
 **dIRECTION** | **NSNumber***| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) | 
 **sTOP** | **NSString***| Specify the value of the Bus Stop ID as an abbreviated string | 

### Return type

[**SWGTimePoints***](SWGTimePoints.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getVehicleLocations**
```objc
-(NSURLSessionTask*) getVehicleLocationsWithROUTE: (NSNumber*) rOUTE
        completionHandler: (void (^)(SWGSuccess* output, NSError* error)) handler;
```



This operation returns a list of vehicles currently in service that have recently (within 5 minutes)  reported their locations. A route paramter is used to return results for the given route.  Use \"0\" for the route parameter to return a list of all vehicles in service.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* rOUTE = @56; // Sepcify the Route ID as an integer.

SWGBusRoutesApi*apiInstance = [[SWGBusRoutesApi alloc] init];

[apiInstance getVehicleLocationsWithROUTE:rOUTE
          completionHandler: ^(SWGSuccess* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBusRoutesApi->getVehicleLocations: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rOUTE** | **NSNumber***| Sepcify the Route ID as an integer. | 

### Return type

[**SWGSuccess***](SWGSuccess.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

