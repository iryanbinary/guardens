# SWGAccessControlApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAuthCode**](SWGAccessControlApi.md#getauthcode) | **GET** /NexTrip/oauth20/authorize | 
[**getTokenRequest**](SWGAccessControlApi.md#gettokenrequest) | **GET** /NexTrip/oauth20/token | 
[**postTokenRequest**](SWGAccessControlApi.md#posttokenrequest) | **POST** /NexTrip/oauth20/token | 


# **getAuthCode**
```objc
-(NSURLSessionTask*) getAuthCodeWithGrantType: (NSString*) grantType
    clientId: (NSString*) clientId
    redirectUri: (NSString*) redirectUri
        completionHandler: (void (^)(SWGSuccess* output, NSError* error)) handler;
```



Request a temporary code for the desired API Access Token Scope(s)

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];

// Configure OAuth2 access token for authorization: (authentication scheme: MobileApp_Implicit)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];

// Configure OAuth2 access token for authorization: (authentication scheme: admin_AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* grantType = @"grantType_example"; // value = authorization_code
NSString* clientId = @"clientId_example"; // a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
NSString* redirectUri = @"redirectUri_example"; // App Callback URI

SWGAccessControlApi*apiInstance = [[SWGAccessControlApi alloc] init];

[apiInstance getAuthCodeWithGrantType:grantType
              clientId:clientId
              redirectUri:redirectUri
          completionHandler: ^(SWGSuccess* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGAccessControlApi->getAuthCode: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grantType** | **NSString***| value &#x3D; authorization_code | 
 **clientId** | **NSString***| a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) | 
 **redirectUri** | **NSString***| App Callback URI | 

### Return type

[**SWGSuccess***](SWGSuccess.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getTokenRequest**
```objc
-(NSURLSessionTask*) getTokenRequestWithGrantType: (NSString*) grantType
    clientId: (NSString*) clientId
    clientSecret: (NSString*) clientSecret
        completionHandler: (void (^)(SWGOAuthToken* output, NSError* error)) handler;
```



Applications request an implicit token with a client id and secret prior to user authentication

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];

// Configure OAuth2 access token for authorization: (authentication scheme: MobileApp_Implicit)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];

// Configure OAuth2 access token for authorization: (authentication scheme: admin_AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* grantType = @"grantType_example"; // value = implicit
NSString* clientId = @"clientId_example"; // a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
NSString* clientSecret = @"clientSecret_example"; // the client secret associated to the app client id (this changes with each app store version iteration)

SWGAccessControlApi*apiInstance = [[SWGAccessControlApi alloc] init];

[apiInstance getTokenRequestWithGrantType:grantType
              clientId:clientId
              clientSecret:clientSecret
          completionHandler: ^(SWGOAuthToken* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGAccessControlApi->getTokenRequest: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grantType** | **NSString***| value &#x3D; implicit | 
 **clientId** | **NSString***| a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) | 
 **clientSecret** | **NSString***| the client secret associated to the app client id (this changes with each app store version iteration) | 

### Return type

[**SWGOAuthToken***](SWGOAuthToken.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **postTokenRequest**
```objc
-(NSURLSessionTask*) postTokenRequestWithCompletionHandler: 
        (void (^)(SWGOAuthToken* output, NSError* error)) handler;
```



Authorization Code grant types require a POST to the token endpoint after a GET for Authorization code.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];

// Configure OAuth2 access token for authorization: (authentication scheme: MobileApp_Implicit)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];

// Configure OAuth2 access token for authorization: (authentication scheme: admin_AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];



SWGAccessControlApi*apiInstance = [[SWGAccessControlApi alloc] init];

[apiInstance postTokenRequestWithCompletionHandler: 
          ^(SWGOAuthToken* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGAccessControlApi->postTokenRequest: %@", error);
                        }
                    }];
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SWGOAuthToken***](SWGOAuthToken.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

