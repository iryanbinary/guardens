# SWGBusRouteInfoApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateroute**](SWGBusRouteInfoApi.md#updateroute) | **POST** /NexTrip/update/{ROUTE} | 


# **updateroute**
```objc
-(NSURLSessionTask*) updaterouteWithROUTE: (NSNumber*) rOUTE
        completionHandler: (void (^)(SWGRouteData* output, NSError* error)) handler;
```



Update a bus route

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: admin_AccessCode)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* rOUTE = @56; // Sepcify the Route ID as an integer.

SWGBusRouteInfoApi*apiInstance = [[SWGBusRouteInfoApi alloc] init];

[apiInstance updaterouteWithROUTE:rOUTE
          completionHandler: ^(SWGRouteData* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBusRouteInfoApi->updateroute: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rOUTE** | **NSNumber***| Sepcify the Route ID as an integer. | 

### Return type

[**SWGRouteData***](SWGRouteData.md)

### Authorization

[admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

