# SWGOAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **NSString*** |  | [optional] 
**refreshToken** | **NSString*** |  | [optional] 
**tokenType** | **NSString*** |  | [optional] 
**expiresIn** | **NSString*** |  | [optional] 
**scopes** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


