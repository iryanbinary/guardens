# SWGTimePoints

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **NSNumber*** |  | [optional] 
**actual** | **NSNumber*** |  | [optional] 
**blockNumber** | **NSNumber*** |  | [optional] 
**departureText** | **NSString*** |  | [optional] 
**departureTime** | **NSString*** |  | [optional] 
**_description** | **NSString*** |  | [optional] 
**gate** | **NSString*** |  | [optional] 
**route** | **NSNumber*** |  | [optional] 
**routeDirection** | **NSString*** |  | [optional] 
**terminal** | **NSString*** |  | [optional] 
**vehicleHeading** | **NSNumber*** |  | [optional] 
**vehicleLatitude** | **NSString*** |  | [optional] 
**vehicleLongitude** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


