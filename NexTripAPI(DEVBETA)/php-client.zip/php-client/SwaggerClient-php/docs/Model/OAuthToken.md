# OAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **string** |  | [optional] 
**refresh_token** | **string** |  | [optional] 
**token_type** | **string** |  | [optional] 
**expires_in** | **string** |  | [optional] 
**scopes** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


