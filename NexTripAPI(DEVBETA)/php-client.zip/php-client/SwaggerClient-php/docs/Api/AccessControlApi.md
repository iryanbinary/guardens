# Swagger\Client\AccessControlApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAuthCode**](AccessControlApi.md#getAuthCode) | **GET** /NexTrip/oauth20/authorize | 
[**getTokenRequest**](AccessControlApi.md#getTokenRequest) | **GET** /NexTrip/oauth20/token | 
[**postTokenRequest**](AccessControlApi.md#postTokenRequest) | **POST** /NexTrip/oauth20/token | 


# **getAuthCode**
> \Swagger\Client\Model\Success getAuthCode($grant_type, $client_id, $redirect_uri)



Request a temporary code for the desired API Access Token Scope(s)

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');
// Configure OAuth2 access token for authorization: MobileApp_Implicit
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');
// Configure OAuth2 access token for authorization: admin_AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\AccessControlApi();
$grant_type = "grant_type_example"; // string | value = authorization_code
$client_id = "client_id_example"; // string | a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
$redirect_uri = "redirect_uri_example"; // string | App Callback URI

try {
    $result = $api_instance->getAuthCode($grant_type, $client_id, $redirect_uri);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AccessControlApi->getAuthCode: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grant_type** | **string**| value &#x3D; authorization_code |
 **client_id** | **string**| a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) |
 **redirect_uri** | **string**| App Callback URI |

### Return type

[**\Swagger\Client\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode), [MobileApp_Implicit](../../README.md#MobileApp_Implicit), [admin_AccessCode](../../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getTokenRequest**
> \Swagger\Client\Model\OAuthToken getTokenRequest($grant_type, $client_id, $client_secret)



Applications request an implicit token with a client id and secret prior to user authentication

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');
// Configure OAuth2 access token for authorization: MobileApp_Implicit
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');
// Configure OAuth2 access token for authorization: admin_AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\AccessControlApi();
$grant_type = "grant_type_example"; // string | value = implicit
$client_id = "client_id_example"; // string | a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
$client_secret = "client_secret_example"; // string | the client secret associated to the app client id (this changes with each app store version iteration)

try {
    $result = $api_instance->getTokenRequest($grant_type, $client_id, $client_secret);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AccessControlApi->getTokenRequest: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grant_type** | **string**| value &#x3D; implicit |
 **client_id** | **string**| a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) |
 **client_secret** | **string**| the client secret associated to the app client id (this changes with each app store version iteration) |

### Return type

[**\Swagger\Client\Model\OAuthToken**](../Model/OAuthToken.md)

### Authorization

[AccessCode](../../README.md#AccessCode), [MobileApp_Implicit](../../README.md#MobileApp_Implicit), [admin_AccessCode](../../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **postTokenRequest**
> \Swagger\Client\Model\OAuthToken postTokenRequest()



Authorization Code grant types require a POST to the token endpoint after a GET for Authorization code.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');
// Configure OAuth2 access token for authorization: MobileApp_Implicit
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');
// Configure OAuth2 access token for authorization: admin_AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\AccessControlApi();

try {
    $result = $api_instance->postTokenRequest();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AccessControlApi->postTokenRequest: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\OAuthToken**](../Model/OAuthToken.md)

### Authorization

[AccessCode](../../README.md#AccessCode), [MobileApp_Implicit](../../README.md#MobileApp_Implicit), [admin_AccessCode](../../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

