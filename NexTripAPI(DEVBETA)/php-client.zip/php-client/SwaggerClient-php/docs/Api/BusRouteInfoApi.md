# Swagger\Client\BusRouteInfoApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateroute**](BusRouteInfoApi.md#updateroute) | **POST** /NexTrip/update/{ROUTE} | 


# **updateroute**
> \Swagger\Client\Model\RouteData updateroute($route)



Update a bus route

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: admin_AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\BusRouteInfoApi();
$route = 56; // int | Sepcify the Route ID as an integer.

try {
    $result = $api_instance->updateroute($route);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BusRouteInfoApi->updateroute: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. |

### Return type

[**\Swagger\Client\Model\RouteData**](../Model/RouteData.md)

### Authorization

[admin_AccessCode](../../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

