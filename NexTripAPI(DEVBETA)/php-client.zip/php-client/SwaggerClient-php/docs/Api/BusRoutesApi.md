# Swagger\Client\BusRoutesApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getDepartures**](BusRoutesApi.md#getDepartures) | **GET** /NexTrip/{STOPID} | 
[**getDirections**](BusRoutesApi.md#getDirections) | **GET** /NexTrip/Directions/{ROUTE} | 
[**getProviders**](BusRoutesApi.md#getProviders) | **GET** /NexTrip/Providers | 
[**getRoutes**](BusRoutesApi.md#getRoutes) | **GET** /NexTrip/Routes | 
[**getStops**](BusRoutesApi.md#getStops) | **GET** /NexTrip/Stops/{ROUTE}/{DIRECTION} | 
[**getTimepointDepartures**](BusRoutesApi.md#getTimepointDepartures) | **GET** /NexTrip/{ROUTE}/{DIRECTION}/{STOP} | 
[**getVehicleLocations**](BusRoutesApi.md#getVehicleLocations) | **GET** /NexTrip/VehicleLocations/{ROUTE} | 


# **getDepartures**
> \Swagger\Client\Model\Success getDepartures($stopid)



Returns a list of departures scheduled for any given bus stop.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\BusRoutesApi();
$stopid = "stopid_example"; // string | Specify the value of the Bus Stop ID as an abbreviated string

try {
    $result = $api_instance->getDepartures($stopid);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BusRoutesApi->getDepartures: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **stopid** | **string**| Specify the value of the Bus Stop ID as an abbreviated string |

### Return type

[**\Swagger\Client\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getDirections**
> \Swagger\Client\Model\Success getDirections($route)



Returns the two directions that are valid for a given route.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\BusRoutesApi();
$route = 56; // int | Sepcify the Route ID as an integer.

try {
    $result = $api_instance->getDirections($route);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BusRoutesApi->getDirections: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. |

### Return type

[**\Swagger\Client\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getProviders**
> \Swagger\Client\Model\Success getProviders()



Returns a list of area Transit providers.  Providers are identified in the list of Routes allowing routes to be selected for a single provider.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\BusRoutesApi();

try {
    $result = $api_instance->getProviders();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BusRoutesApi->getProviders: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getRoutes**
> \Swagger\Client\Model\RouteData getRoutes()



Returns a list of Transit routes that are in service on the current day.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\BusRoutesApi();

try {
    $result = $api_instance->getRoutes();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BusRoutesApi->getRoutes: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\RouteData**](../Model/RouteData.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getStops**
> \Swagger\Client\Model\Success getStops($route, $direction)



Returns a list of Timepoint stops for the given Route/Direction.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\BusRoutesApi();
$route = 56; // int | Sepcify the Route ID as an integer.
$direction = 56; // int | Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)

try {
    $result = $api_instance->getStops($route, $direction);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BusRoutesApi->getStops: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. |
 **direction** | **int**| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) |

### Return type

[**\Swagger\Client\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getTimepointDepartures**
> \Swagger\Client\Model\TimePoints getTimepointDepartures($route, $direction, $stop)



Returns the scheduled departures for a selected route, direction and timepoint stop.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\BusRoutesApi();
$route = 56; // int | Sepcify the Route ID as an integer.
$direction = 56; // int | Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)
$stop = "stop_example"; // string | Specify the value of the Bus Stop ID as an abbreviated string

try {
    $result = $api_instance->getTimepointDepartures($route, $direction, $stop);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BusRoutesApi->getTimepointDepartures: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. |
 **direction** | **int**| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) |
 **stop** | **string**| Specify the value of the Bus Stop ID as an abbreviated string |

### Return type

[**\Swagger\Client\Model\TimePoints**](../Model/TimePoints.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getVehicleLocations**
> \Swagger\Client\Model\Success getVehicleLocations($route)



This operation returns a list of vehicles currently in service that have recently (within 5 minutes)  reported their locations. A route paramter is used to return results for the given route.  Use \"0\" for the route parameter to return a list of all vehicles in service.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: AccessCode
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\BusRoutesApi();
$route = 56; // int | Sepcify the Route ID as an integer.

try {
    $result = $api_instance->getVehicleLocations($route);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BusRoutesApi->getVehicleLocations: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. |

### Return type

[**\Swagger\Client\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

