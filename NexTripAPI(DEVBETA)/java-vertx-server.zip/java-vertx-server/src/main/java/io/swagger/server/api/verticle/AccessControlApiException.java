package io.swagger.server.api.verticle;

import io.swagger.server.api.model.Err;
import io.swagger.server.api.MainApiException;
import io.swagger.server.api.model.OAuthToken;
import io.swagger.server.api.model.Success;

public final class AccessControlApiException extends MainApiException {
    public AccessControlApiException(int statusCode, String statusMessage) {
        super(statusCode, statusMessage);
    }
    
    public static final AccessControlApiException AccessControl_getAuthCode_401_Exception = new AccessControlApiException(401, "Unknown User, Not Authenticated");
    public static final AccessControlApiException AccessControl_getAuthCode_403_Exception = new AccessControlApiException(403, "Not Authorized.  Missing Authorization Header, Unknown User or App ID or incorrect password or secret.");
    public static final AccessControlApiException AccessControl_getAuthCode_418_Exception = new AccessControlApiException(418, "Tea Kettles are not currently supported in this version of the API");
    public static final AccessControlApiException AccessControl_getAuthCode_429_Exception = new AccessControlApiException(429, "Transaction Volume Quota Exceeded, try again in 1 minute.");
    public static final AccessControlApiException AccessControl_getAuthCode_500_Exception = new AccessControlApiException(500, "Incomplete Request or Server Error");
    public static final AccessControlApiException AccessControl_getTokenRequest_401_Exception = new AccessControlApiException(401, "Unknown User, Not Authenticated");
    public static final AccessControlApiException AccessControl_getTokenRequest_403_Exception = new AccessControlApiException(403, "Not Authorized.  Missing Authorization Header, Unknown User or App ID or incorrect password or secret.");
    public static final AccessControlApiException AccessControl_getTokenRequest_429_Exception = new AccessControlApiException(429, "Transaction Volume Quota Exceeded, try again in 1 minute.");
    public static final AccessControlApiException AccessControl_getTokenRequest_500_Exception = new AccessControlApiException(500, "Bad Request (User Error, Network Packet Loss), Server Error");
    public static final AccessControlApiException AccessControl_postTokenRequest_401_Exception = new AccessControlApiException(401, "Unknown User, Not Authenticated");
    public static final AccessControlApiException AccessControl_postTokenRequest_403_Exception = new AccessControlApiException(403, "Not Authorized.  Missing Authorization Header, Unknown User or App ID or incorrect password or secret.");
    public static final AccessControlApiException AccessControl_postTokenRequest_429_Exception = new AccessControlApiException(429, "Transaction Volume Quota Exceeded, try again in 1 minute.");
    public static final AccessControlApiException AccessControl_postTokenRequest_500_Exception = new AccessControlApiException(500, "Incomplete Request or Server Error");
    

}