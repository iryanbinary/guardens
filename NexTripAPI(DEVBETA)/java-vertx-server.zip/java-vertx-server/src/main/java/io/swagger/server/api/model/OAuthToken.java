package io.swagger.server.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL) 
public class OAuthToken   {
  
  private String token = null;
  private String refreshToken = null;
  private String tokenType = null;
  private String expiresIn = null;
  private String scopes = null;

  public OAuthToken () {

  }

  public OAuthToken (String token, String refreshToken, String tokenType, String expiresIn, String scopes) {
    this.token = token;
    this.refreshToken = refreshToken;
    this.tokenType = tokenType;
    this.expiresIn = expiresIn;
    this.scopes = scopes;
  }

    
  @JsonProperty("token")
  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

    
  @JsonProperty("refresh_token")
  public String getRefreshToken() {
    return refreshToken;
  }
  public void setRefreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
  }

    
  @JsonProperty("token_type")
  public String getTokenType() {
    return tokenType;
  }
  public void setTokenType(String tokenType) {
    this.tokenType = tokenType;
  }

    
  @JsonProperty("expires_in")
  public String getExpiresIn() {
    return expiresIn;
  }
  public void setExpiresIn(String expiresIn) {
    this.expiresIn = expiresIn;
  }

    
  @JsonProperty("scopes")
  public String getScopes() {
    return scopes;
  }
  public void setScopes(String scopes) {
    this.scopes = scopes;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OAuthToken oauthToken = (OAuthToken) o;
    return Objects.equals(token, oauthToken.token) &&
        Objects.equals(refreshToken, oauthToken.refreshToken) &&
        Objects.equals(tokenType, oauthToken.tokenType) &&
        Objects.equals(expiresIn, oauthToken.expiresIn) &&
        Objects.equals(scopes, oauthToken.scopes);
  }

  @Override
  public int hashCode() {
    return Objects.hash(token, refreshToken, tokenType, expiresIn, scopes);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OAuthToken {\n");
    
    sb.append("    token: ").append(toIndentedString(token)).append("\n");
    sb.append("    refreshToken: ").append(toIndentedString(refreshToken)).append("\n");
    sb.append("    tokenType: ").append(toIndentedString(tokenType)).append("\n");
    sb.append("    expiresIn: ").append(toIndentedString(expiresIn)).append("\n");
    sb.append("    scopes: ").append(toIndentedString(scopes)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
