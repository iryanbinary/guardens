package io.swagger.server.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL) 
public class RouteData   {
  
  private Integer code = null;
  private Integer route = null;
  private Integer providerID = null;
  private String description = null;

  public RouteData () {

  }

  public RouteData (Integer code, Integer route, Integer providerID, String description) {
    this.code = code;
    this.route = route;
    this.providerID = providerID;
    this.description = description;
  }

    
  @JsonProperty("code")
  public Integer getCode() {
    return code;
  }
  public void setCode(Integer code) {
    this.code = code;
  }

    
  @JsonProperty("Route")
  public Integer getRoute() {
    return route;
  }
  public void setRoute(Integer route) {
    this.route = route;
  }

    
  @JsonProperty("ProviderID")
  public Integer getProviderID() {
    return providerID;
  }
  public void setProviderID(Integer providerID) {
    this.providerID = providerID;
  }

    
  @JsonProperty("Description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RouteData routeData = (RouteData) o;
    return Objects.equals(code, routeData.code) &&
        Objects.equals(route, routeData.route) &&
        Objects.equals(providerID, routeData.providerID) &&
        Objects.equals(description, routeData.description);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, route, providerID, description);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RouteData {\n");
    
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    route: ").append(toIndentedString(route)).append("\n");
    sb.append("    providerID: ").append(toIndentedString(providerID)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
