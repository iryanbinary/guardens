package io.swagger.server.api.verticle;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.Message;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;

import io.swagger.server.api.model.Err;
import io.swagger.server.api.MainApiException;
import io.swagger.server.api.model.OAuthToken;
import io.swagger.server.api.model.Success;

import java.util.List;
import java.util.Map;

public class AccessControlApiVerticle extends AbstractVerticle {
    final static Logger LOGGER = LoggerFactory.getLogger(AccessControlApiVerticle.class); 
    
    final static String GETAUTHCODE_SERVICE_ID = "GetAuthCode";
    final static String GETTOKENREQUEST_SERVICE_ID = "GetTokenRequest";
    final static String POSTTOKENREQUEST_SERVICE_ID = "PostTokenRequest";
    
    //TODO : create Implementation
    AccessControlApi service = new AccessControlApiImpl();

    @Override
    public void start() throws Exception {
        
        //Consumer for GetAuthCode
        vertx.eventBus().<JsonObject> consumer(GETAUTHCODE_SERVICE_ID).handler(message -> {
            try {
                String grantType = message.body().getString("grant_type");
                String clientId = message.body().getString("client_id");
                String redirectUri = message.body().getString("redirect_uri");
                service.getAuthCode(grantType, clientId, redirectUri, result -> {
                    if (result.succeeded())
                        message.reply(new JsonObject(Json.encode(result.result())).encodePrettily());
                    else {
                        Throwable cause = result.cause();
                        manageError(message, cause, "GetAuthCode");
                    }
                });
            } catch (Exception e) {
                logUnexpectedError("GetAuthCode", e);
                message.fail(MainApiException.INTERNAL_SERVER_ERROR.getStatusCode(), MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage());
            }
        });
        
        //Consumer for GetTokenRequest
        vertx.eventBus().<JsonObject> consumer(GETTOKENREQUEST_SERVICE_ID).handler(message -> {
            try {
                String grantType = message.body().getString("grant_type");
                String clientId = message.body().getString("client_id");
                String clientSecret = message.body().getString("client_secret");
                service.getTokenRequest(grantType, clientId, clientSecret, result -> {
                    if (result.succeeded())
                        message.reply(new JsonObject(Json.encode(result.result())).encodePrettily());
                    else {
                        Throwable cause = result.cause();
                        manageError(message, cause, "GetTokenRequest");
                    }
                });
            } catch (Exception e) {
                logUnexpectedError("GetTokenRequest", e);
                message.fail(MainApiException.INTERNAL_SERVER_ERROR.getStatusCode(), MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage());
            }
        });
        
        //Consumer for PostTokenRequest
        vertx.eventBus().<JsonObject> consumer(POSTTOKENREQUEST_SERVICE_ID).handler(message -> {
            try {
                service.postTokenRequest(result -> {
                    if (result.succeeded())
                        message.reply(new JsonObject(Json.encode(result.result())).encodePrettily());
                    else {
                        Throwable cause = result.cause();
                        manageError(message, cause, "PostTokenRequest");
                    }
                });
            } catch (Exception e) {
                logUnexpectedError("PostTokenRequest", e);
                message.fail(MainApiException.INTERNAL_SERVER_ERROR.getStatusCode(), MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage());
            }
        });
        
    }
    
    private void manageError(Message<JsonObject> message, Throwable cause, String serviceName) {
        int code = MainApiException.INTERNAL_SERVER_ERROR.getStatusCode();
        String statusMessage = MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage();
        if (cause instanceof MainApiException) {
            code = ((MainApiException)cause).getStatusCode();
            statusMessage = ((MainApiException)cause).getStatusMessage();
        } else {
            logUnexpectedError(serviceName, cause); 
        }
            
        message.fail(code, statusMessage);
    }
    
    private void logUnexpectedError(String serviceName, Throwable cause) {
        LOGGER.error("Unexpected error in "+ serviceName, cause);
    }
}
