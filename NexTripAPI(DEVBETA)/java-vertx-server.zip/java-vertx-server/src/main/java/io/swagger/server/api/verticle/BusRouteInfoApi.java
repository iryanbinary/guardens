package io.swagger.server.api.verticle;

import io.swagger.server.api.model.Err;
import io.swagger.server.api.MainApiException;
import io.swagger.server.api.model.RouteData;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

import java.util.List;
import java.util.Map;

public interface BusRouteInfoApi  {
    //updateroute
    void updateroute(Integer ROUTE, Handler<AsyncResult<RouteData>> handler);
    
}
