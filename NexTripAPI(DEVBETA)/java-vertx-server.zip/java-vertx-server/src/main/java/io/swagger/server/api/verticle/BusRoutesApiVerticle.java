package io.swagger.server.api.verticle;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.Message;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;

import io.swagger.server.api.model.Err;
import io.swagger.server.api.MainApiException;
import io.swagger.server.api.model.RouteData;
import io.swagger.server.api.model.Success;
import io.swagger.server.api.model.TimePoints;

import java.util.List;
import java.util.Map;

public class BusRoutesApiVerticle extends AbstractVerticle {
    final static Logger LOGGER = LoggerFactory.getLogger(BusRoutesApiVerticle.class); 
    
    final static String GETDEPARTURES_SERVICE_ID = "GetDepartures";
    final static String GETDIRECTIONS_SERVICE_ID = "GetDirections";
    final static String GETPROVIDERS_SERVICE_ID = "GetProviders";
    final static String GETROUTES_SERVICE_ID = "GetRoutes";
    final static String GETSTOPS_SERVICE_ID = "GetStops";
    final static String GETTIMEPOINTDEPARTURES_SERVICE_ID = "GetTimepointDepartures";
    final static String GETVEHICLELOCATIONS_SERVICE_ID = "GetVehicleLocations";
    
    //TODO : create Implementation
    BusRoutesApi service = new BusRoutesApiImpl();

    @Override
    public void start() throws Exception {
        
        //Consumer for GetDepartures
        vertx.eventBus().<JsonObject> consumer(GETDEPARTURES_SERVICE_ID).handler(message -> {
            try {
                String STOPID = message.body().getString("STOPID");
                service.getDepartures(STOPID, result -> {
                    if (result.succeeded())
                        message.reply(new JsonObject(Json.encode(result.result())).encodePrettily());
                    else {
                        Throwable cause = result.cause();
                        manageError(message, cause, "GetDepartures");
                    }
                });
            } catch (Exception e) {
                logUnexpectedError("GetDepartures", e);
                message.fail(MainApiException.INTERNAL_SERVER_ERROR.getStatusCode(), MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage());
            }
        });
        
        //Consumer for GetDirections
        vertx.eventBus().<JsonObject> consumer(GETDIRECTIONS_SERVICE_ID).handler(message -> {
            try {
                Integer ROUTE = Json.mapper.readValue(message.body().getString("ROUTE"), Integer.class);
                service.getDirections(ROUTE, result -> {
                    if (result.succeeded())
                        message.reply(new JsonObject(Json.encode(result.result())).encodePrettily());
                    else {
                        Throwable cause = result.cause();
                        manageError(message, cause, "GetDirections");
                    }
                });
            } catch (Exception e) {
                logUnexpectedError("GetDirections", e);
                message.fail(MainApiException.INTERNAL_SERVER_ERROR.getStatusCode(), MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage());
            }
        });
        
        //Consumer for GetProviders
        vertx.eventBus().<JsonObject> consumer(GETPROVIDERS_SERVICE_ID).handler(message -> {
            try {
                service.getProviders(result -> {
                    if (result.succeeded())
                        message.reply(new JsonObject(Json.encode(result.result())).encodePrettily());
                    else {
                        Throwable cause = result.cause();
                        manageError(message, cause, "GetProviders");
                    }
                });
            } catch (Exception e) {
                logUnexpectedError("GetProviders", e);
                message.fail(MainApiException.INTERNAL_SERVER_ERROR.getStatusCode(), MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage());
            }
        });
        
        //Consumer for GetRoutes
        vertx.eventBus().<JsonObject> consumer(GETROUTES_SERVICE_ID).handler(message -> {
            try {
                service.getRoutes(result -> {
                    if (result.succeeded())
                        message.reply(new JsonObject(Json.encode(result.result())).encodePrettily());
                    else {
                        Throwable cause = result.cause();
                        manageError(message, cause, "GetRoutes");
                    }
                });
            } catch (Exception e) {
                logUnexpectedError("GetRoutes", e);
                message.fail(MainApiException.INTERNAL_SERVER_ERROR.getStatusCode(), MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage());
            }
        });
        
        //Consumer for GetStops
        vertx.eventBus().<JsonObject> consumer(GETSTOPS_SERVICE_ID).handler(message -> {
            try {
                Integer ROUTE = Json.mapper.readValue(message.body().getString("ROUTE"), Integer.class);
                Integer DIRECTION = Json.mapper.readValue(message.body().getString("DIRECTION"), Integer.class);
                service.getStops(ROUTE, DIRECTION, result -> {
                    if (result.succeeded())
                        message.reply(new JsonObject(Json.encode(result.result())).encodePrettily());
                    else {
                        Throwable cause = result.cause();
                        manageError(message, cause, "GetStops");
                    }
                });
            } catch (Exception e) {
                logUnexpectedError("GetStops", e);
                message.fail(MainApiException.INTERNAL_SERVER_ERROR.getStatusCode(), MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage());
            }
        });
        
        //Consumer for GetTimepointDepartures
        vertx.eventBus().<JsonObject> consumer(GETTIMEPOINTDEPARTURES_SERVICE_ID).handler(message -> {
            try {
                Integer ROUTE = Json.mapper.readValue(message.body().getString("ROUTE"), Integer.class);
                Integer DIRECTION = Json.mapper.readValue(message.body().getString("DIRECTION"), Integer.class);
                String STOP = message.body().getString("STOP");
                service.getTimepointDepartures(ROUTE, DIRECTION, STOP, result -> {
                    if (result.succeeded())
                        message.reply(new JsonObject(Json.encode(result.result())).encodePrettily());
                    else {
                        Throwable cause = result.cause();
                        manageError(message, cause, "GetTimepointDepartures");
                    }
                });
            } catch (Exception e) {
                logUnexpectedError("GetTimepointDepartures", e);
                message.fail(MainApiException.INTERNAL_SERVER_ERROR.getStatusCode(), MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage());
            }
        });
        
        //Consumer for GetVehicleLocations
        vertx.eventBus().<JsonObject> consumer(GETVEHICLELOCATIONS_SERVICE_ID).handler(message -> {
            try {
                Integer ROUTE = Json.mapper.readValue(message.body().getString("ROUTE"), Integer.class);
                service.getVehicleLocations(ROUTE, result -> {
                    if (result.succeeded())
                        message.reply(new JsonObject(Json.encode(result.result())).encodePrettily());
                    else {
                        Throwable cause = result.cause();
                        manageError(message, cause, "GetVehicleLocations");
                    }
                });
            } catch (Exception e) {
                logUnexpectedError("GetVehicleLocations", e);
                message.fail(MainApiException.INTERNAL_SERVER_ERROR.getStatusCode(), MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage());
            }
        });
        
    }
    
    private void manageError(Message<JsonObject> message, Throwable cause, String serviceName) {
        int code = MainApiException.INTERNAL_SERVER_ERROR.getStatusCode();
        String statusMessage = MainApiException.INTERNAL_SERVER_ERROR.getStatusMessage();
        if (cause instanceof MainApiException) {
            code = ((MainApiException)cause).getStatusCode();
            statusMessage = ((MainApiException)cause).getStatusMessage();
        } else {
            logUnexpectedError(serviceName, cause); 
        }
            
        message.fail(code, statusMessage);
    }
    
    private void logUnexpectedError(String serviceName, Throwable cause) {
        LOGGER.error("Unexpected error in "+ serviceName, cause);
    }
}
