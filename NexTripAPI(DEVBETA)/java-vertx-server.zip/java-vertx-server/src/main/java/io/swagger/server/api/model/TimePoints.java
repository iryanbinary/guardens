package io.swagger.server.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL) 
public class TimePoints   {
  
  private Integer code = null;
  private Boolean actual = null;
  private Integer blockNumber = null;
  private String departureText = null;
  private String departureTime = null;
  private String description = null;
  private String gate = null;
  private Integer route = null;
  private String routeDirection = null;
  private String terminal = null;
  private Integer vehicleHeading = null;
  private String vehicleLatitude = null;
  private String vehicleLongitude = null;

  public TimePoints () {

  }

  public TimePoints (Integer code, Boolean actual, Integer blockNumber, String departureText, String departureTime, String description, String gate, Integer route, String routeDirection, String terminal, Integer vehicleHeading, String vehicleLatitude, String vehicleLongitude) {
    this.code = code;
    this.actual = actual;
    this.blockNumber = blockNumber;
    this.departureText = departureText;
    this.departureTime = departureTime;
    this.description = description;
    this.gate = gate;
    this.route = route;
    this.routeDirection = routeDirection;
    this.terminal = terminal;
    this.vehicleHeading = vehicleHeading;
    this.vehicleLatitude = vehicleLatitude;
    this.vehicleLongitude = vehicleLongitude;
  }

    
  @JsonProperty("code")
  public Integer getCode() {
    return code;
  }
  public void setCode(Integer code) {
    this.code = code;
  }

    
  @JsonProperty("Actual")
  public Boolean getActual() {
    return actual;
  }
  public void setActual(Boolean actual) {
    this.actual = actual;
  }

    
  @JsonProperty("BlockNumber")
  public Integer getBlockNumber() {
    return blockNumber;
  }
  public void setBlockNumber(Integer blockNumber) {
    this.blockNumber = blockNumber;
  }

    
  @JsonProperty("DepartureText")
  public String getDepartureText() {
    return departureText;
  }
  public void setDepartureText(String departureText) {
    this.departureText = departureText;
  }

    
  @JsonProperty("DepartureTime")
  public String getDepartureTime() {
    return departureTime;
  }
  public void setDepartureTime(String departureTime) {
    this.departureTime = departureTime;
  }

    
  @JsonProperty("Description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

    
  @JsonProperty("Gate")
  public String getGate() {
    return gate;
  }
  public void setGate(String gate) {
    this.gate = gate;
  }

    
  @JsonProperty("Route")
  public Integer getRoute() {
    return route;
  }
  public void setRoute(Integer route) {
    this.route = route;
  }

    
  @JsonProperty("RouteDirection")
  public String getRouteDirection() {
    return routeDirection;
  }
  public void setRouteDirection(String routeDirection) {
    this.routeDirection = routeDirection;
  }

    
  @JsonProperty("Terminal")
  public String getTerminal() {
    return terminal;
  }
  public void setTerminal(String terminal) {
    this.terminal = terminal;
  }

    
  @JsonProperty("VehicleHeading")
  public Integer getVehicleHeading() {
    return vehicleHeading;
  }
  public void setVehicleHeading(Integer vehicleHeading) {
    this.vehicleHeading = vehicleHeading;
  }

    
  @JsonProperty("VehicleLatitude")
  public String getVehicleLatitude() {
    return vehicleLatitude;
  }
  public void setVehicleLatitude(String vehicleLatitude) {
    this.vehicleLatitude = vehicleLatitude;
  }

    
  @JsonProperty("VehicleLongitude")
  public String getVehicleLongitude() {
    return vehicleLongitude;
  }
  public void setVehicleLongitude(String vehicleLongitude) {
    this.vehicleLongitude = vehicleLongitude;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TimePoints timePoints = (TimePoints) o;
    return Objects.equals(code, timePoints.code) &&
        Objects.equals(actual, timePoints.actual) &&
        Objects.equals(blockNumber, timePoints.blockNumber) &&
        Objects.equals(departureText, timePoints.departureText) &&
        Objects.equals(departureTime, timePoints.departureTime) &&
        Objects.equals(description, timePoints.description) &&
        Objects.equals(gate, timePoints.gate) &&
        Objects.equals(route, timePoints.route) &&
        Objects.equals(routeDirection, timePoints.routeDirection) &&
        Objects.equals(terminal, timePoints.terminal) &&
        Objects.equals(vehicleHeading, timePoints.vehicleHeading) &&
        Objects.equals(vehicleLatitude, timePoints.vehicleLatitude) &&
        Objects.equals(vehicleLongitude, timePoints.vehicleLongitude);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, actual, blockNumber, departureText, departureTime, description, gate, route, routeDirection, terminal, vehicleHeading, vehicleLatitude, vehicleLongitude);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TimePoints {\n");
    
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    actual: ").append(toIndentedString(actual)).append("\n");
    sb.append("    blockNumber: ").append(toIndentedString(blockNumber)).append("\n");
    sb.append("    departureText: ").append(toIndentedString(departureText)).append("\n");
    sb.append("    departureTime: ").append(toIndentedString(departureTime)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    gate: ").append(toIndentedString(gate)).append("\n");
    sb.append("    route: ").append(toIndentedString(route)).append("\n");
    sb.append("    routeDirection: ").append(toIndentedString(routeDirection)).append("\n");
    sb.append("    terminal: ").append(toIndentedString(terminal)).append("\n");
    sb.append("    vehicleHeading: ").append(toIndentedString(vehicleHeading)).append("\n");
    sb.append("    vehicleLatitude: ").append(toIndentedString(vehicleLatitude)).append("\n");
    sb.append("    vehicleLongitude: ").append(toIndentedString(vehicleLongitude)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
