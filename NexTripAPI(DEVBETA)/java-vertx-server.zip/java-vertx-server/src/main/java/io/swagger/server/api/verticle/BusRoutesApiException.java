package io.swagger.server.api.verticle;

import io.swagger.server.api.model.Err;
import io.swagger.server.api.MainApiException;
import io.swagger.server.api.model.RouteData;
import io.swagger.server.api.model.Success;
import io.swagger.server.api.model.TimePoints;

public final class BusRoutesApiException extends MainApiException {
    public BusRoutesApiException(int statusCode, String statusMessage) {
        super(statusCode, statusMessage);
    }
    
    public static final BusRoutesApiException BusRoutes_getDepartures_401_Exception = new BusRoutesApiException(401, "Unknown User, Not Authenticated");
    public static final BusRoutesApiException BusRoutes_getDepartures_403_Exception = new BusRoutesApiException(403, "Not Authorized. Expired or Missing Access Token, or Access Token lacks the scope of entitlement required");
    public static final BusRoutesApiException BusRoutes_getDepartures_429_Exception = new BusRoutesApiException(429, "Transaction Volume Quota Exceeded, try again in 1 minute.");
    public static final BusRoutesApiException BusRoutes_getDepartures_500_Exception = new BusRoutesApiException(500, "Incomplete Request or Server Error");
    public static final BusRoutesApiException BusRoutes_getDirections_401_Exception = new BusRoutesApiException(401, "Unknown User, Not Authenticated");
    public static final BusRoutesApiException BusRoutes_getDirections_403_Exception = new BusRoutesApiException(403, "Not Authorized. Expired or Missing Access Token, or Access Token lacks the scope of entitlement required");
    public static final BusRoutesApiException BusRoutes_getDirections_429_Exception = new BusRoutesApiException(429, "Transaction Volume Quota Exceeded, try again in 1 minute.");
    public static final BusRoutesApiException BusRoutes_getDirections_500_Exception = new BusRoutesApiException(500, "Incomplete Request or Server Error");
    public static final BusRoutesApiException BusRoutes_getProviders_401_Exception = new BusRoutesApiException(401, "Unknown User, Not Authenticated");
    public static final BusRoutesApiException BusRoutes_getProviders_403_Exception = new BusRoutesApiException(403, "Not Authorized. Expired or Missing Access Token, or Access Token lacks the scope of entitlement required");
    public static final BusRoutesApiException BusRoutes_getProviders_429_Exception = new BusRoutesApiException(429, "Transaction Volume Quota Exceeded, try again in 1 minute.");
    public static final BusRoutesApiException BusRoutes_getProviders_500_Exception = new BusRoutesApiException(500, "Incomplete Request or Server Error");
    public static final BusRoutesApiException BusRoutes_getRoutes_401_Exception = new BusRoutesApiException(401, "Unknown User, Not Authenticated");
    public static final BusRoutesApiException BusRoutes_getRoutes_403_Exception = new BusRoutesApiException(403, "Not Authorized. Expired or Missing Access Token, or Access Token lacks the scope of entitlement required");
    public static final BusRoutesApiException BusRoutes_getRoutes_429_Exception = new BusRoutesApiException(429, "Transaction Volume Quota Exceeded, try again in 1 minute.");
    public static final BusRoutesApiException BusRoutes_getRoutes_500_Exception = new BusRoutesApiException(500, "Incomplete Request or Server Error");
    public static final BusRoutesApiException BusRoutes_getStops_401_Exception = new BusRoutesApiException(401, "Unknown User, Not Authenticated");
    public static final BusRoutesApiException BusRoutes_getStops_403_Exception = new BusRoutesApiException(403, "Not Authorized. Expired or Missing Access Token, or Access Token lacks the scope of entitlement required");
    public static final BusRoutesApiException BusRoutes_getStops_429_Exception = new BusRoutesApiException(429, "Transaction Volume Quota Exceeded, try again in 1 minute.");
    public static final BusRoutesApiException BusRoutes_getStops_500_Exception = new BusRoutesApiException(500, "Incomplete Request or Server Error");
    public static final BusRoutesApiException BusRoutes_getTimepointDepartures_401_Exception = new BusRoutesApiException(401, "Unknown User, Not Authenticated");
    public static final BusRoutesApiException BusRoutes_getTimepointDepartures_403_Exception = new BusRoutesApiException(403, "Not Authorized. Expired or Missing Access Token, or Access Token lacks the scope of entitlement required");
    public static final BusRoutesApiException BusRoutes_getTimepointDepartures_429_Exception = new BusRoutesApiException(429, "Transaction Volume Quota Exceeded, try again in 1 minute.");
    public static final BusRoutesApiException BusRoutes_getTimepointDepartures_500_Exception = new BusRoutesApiException(500, "Incomplete Request or Server Error");
    public static final BusRoutesApiException BusRoutes_getVehicleLocations_401_Exception = new BusRoutesApiException(401, "Unknown User, Not Authenticated");
    public static final BusRoutesApiException BusRoutes_getVehicleLocations_403_Exception = new BusRoutesApiException(403, "Not Authorized. Expired or Missing Access Token, or Access Token lacks the scope of entitlement required");
    public static final BusRoutesApiException BusRoutes_getVehicleLocations_429_Exception = new BusRoutesApiException(429, "Transaction Volume Quota Exceeded, try again in 1 minute.");
    public static final BusRoutesApiException BusRoutes_getVehicleLocations_500_Exception = new BusRoutesApiException(500, "Incomplete Request or Server Error");
    

}