package io.swagger.server.api.verticle;

import io.swagger.server.api.model.Err;
import io.swagger.server.api.MainApiException;
import io.swagger.server.api.model.OAuthToken;
import io.swagger.server.api.model.Success;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

import java.util.List;
import java.util.Map;

public interface AccessControlApi  {
    //GetAuthCode
    void getAuthCode(String grantType, String clientId, String redirectUri, Handler<AsyncResult<Success>> handler);
    
    //GetTokenRequest
    void getTokenRequest(String grantType, String clientId, String clientSecret, Handler<AsyncResult<OAuthToken>> handler);
    
    //PostTokenRequest
    void postTokenRequest(Handler<AsyncResult<OAuthToken>> handler);
    
}
