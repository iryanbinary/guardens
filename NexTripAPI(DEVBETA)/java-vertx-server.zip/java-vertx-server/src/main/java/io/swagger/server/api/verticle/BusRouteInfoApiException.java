package io.swagger.server.api.verticle;

import io.swagger.server.api.model.Err;
import io.swagger.server.api.MainApiException;
import io.swagger.server.api.model.RouteData;

public final class BusRouteInfoApiException extends MainApiException {
    public BusRouteInfoApiException(int statusCode, String statusMessage) {
        super(statusCode, statusMessage);
    }
    
    public static final BusRouteInfoApiException BusRouteInfo_updateroute_401_Exception = new BusRouteInfoApiException(401, "Unknown User, Not Authenticated");
    public static final BusRouteInfoApiException BusRouteInfo_updateroute_403_Exception = new BusRouteInfoApiException(403, "Not Authorized. Expired or Missing Access Token. Or Access Token lacks the scope of entitlement required");
    public static final BusRouteInfoApiException BusRouteInfo_updateroute_429_Exception = new BusRouteInfoApiException(429, "Transaction Volume Quota Exceeded, try again in 1 minute.");
    public static final BusRouteInfoApiException BusRouteInfo_updateroute_500_Exception = new BusRouteInfoApiException(500, "Incomplete Request or Server Error");
    

}