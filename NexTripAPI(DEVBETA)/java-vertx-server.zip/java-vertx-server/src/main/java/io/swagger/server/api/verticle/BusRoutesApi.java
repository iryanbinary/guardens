package io.swagger.server.api.verticle;

import io.swagger.server.api.model.Err;
import io.swagger.server.api.MainApiException;
import io.swagger.server.api.model.RouteData;
import io.swagger.server.api.model.Success;
import io.swagger.server.api.model.TimePoints;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

import java.util.List;
import java.util.Map;

public interface BusRoutesApi  {
    //GetDepartures
    void getDepartures(String STOPID, Handler<AsyncResult<Success>> handler);
    
    //GetDirections
    void getDirections(Integer ROUTE, Handler<AsyncResult<Success>> handler);
    
    //GetProviders
    void getProviders(Handler<AsyncResult<Success>> handler);
    
    //GetRoutes
    void getRoutes(Handler<AsyncResult<RouteData>> handler);
    
    //GetStops
    void getStops(Integer ROUTE, Integer DIRECTION, Handler<AsyncResult<Success>> handler);
    
    //GetTimepointDepartures
    void getTimepointDepartures(Integer ROUTE, Integer DIRECTION, String STOP, Handler<AsyncResult<TimePoints>> handler);
    
    //GetVehicleLocations
    void getVehicleLocations(Integer ROUTE, Handler<AsyncResult<Success>> handler);
    
}
