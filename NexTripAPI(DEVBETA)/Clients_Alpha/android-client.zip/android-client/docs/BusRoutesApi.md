# BusRoutesApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getDepartures**](BusRoutesApi.md#getDepartures) | **GET** /NexTrip/{STOPID} | 
[**getDirections**](BusRoutesApi.md#getDirections) | **GET** /NexTrip/Directions/{ROUTE} | 
[**getProviders**](BusRoutesApi.md#getProviders) | **GET** /NexTrip/Providers | 
[**getRoutes**](BusRoutesApi.md#getRoutes) | **GET** /NexTrip/Routes | 
[**getStops**](BusRoutesApi.md#getStops) | **GET** /NexTrip/Stops/{ROUTE}/{DIRECTION} | 
[**getTimepointDepartures**](BusRoutesApi.md#getTimepointDepartures) | **GET** /NexTrip/{ROUTE}/{DIRECTION}/{STOP} | 
[**getVehicleLocations**](BusRoutesApi.md#getVehicleLocations) | **GET** /NexTrip/VehicleLocations/{ROUTE} | 


<a name="getDepartures"></a>
# **getDepartures**
> Success getDepartures(STOPID)



Returns a list of departures scheduled for any given bus stop.

### Example
```java
// Import classes:
//import io.swagger.client.api.BusRoutesApi;

BusRoutesApi apiInstance = new BusRoutesApi();
String STOPID = "STOPID_example"; // String | Specify the value of the Bus Stop ID as an abbreviated string
try {
    Success result = apiInstance.getDepartures(STOPID);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BusRoutesApi#getDepartures");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **STOPID** | **String**| Specify the value of the Bus Stop ID as an abbreviated string |

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

<a name="getDirections"></a>
# **getDirections**
> Success getDirections(ROUTE)



Returns the two directions that are valid for a given route.

### Example
```java
// Import classes:
//import io.swagger.client.api.BusRoutesApi;

BusRoutesApi apiInstance = new BusRoutesApi();
Integer ROUTE = 56; // Integer | Sepcify the Route ID as an integer.
try {
    Success result = apiInstance.getDirections(ROUTE);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BusRoutesApi#getDirections");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ROUTE** | **Integer**| Sepcify the Route ID as an integer. |

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

<a name="getProviders"></a>
# **getProviders**
> Success getProviders()



Returns a list of area Transit providers.  Providers are identified in the list of Routes allowing routes to be selected for a single provider. 

### Example
```java
// Import classes:
//import io.swagger.client.api.BusRoutesApi;

BusRoutesApi apiInstance = new BusRoutesApi();
try {
    Success result = apiInstance.getProviders();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BusRoutesApi#getProviders");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

<a name="getRoutes"></a>
# **getRoutes**
> RouteData getRoutes()



Returns a list of Transit routes that are in service on the current day.

### Example
```java
// Import classes:
//import io.swagger.client.api.BusRoutesApi;

BusRoutesApi apiInstance = new BusRoutesApi();
try {
    RouteData result = apiInstance.getRoutes();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BusRoutesApi#getRoutes");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**RouteData**](RouteData.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

<a name="getStops"></a>
# **getStops**
> Success getStops(ROUTE, DIRECTION)



Returns a list of Timepoint stops for the given Route/Direction.

### Example
```java
// Import classes:
//import io.swagger.client.api.BusRoutesApi;

BusRoutesApi apiInstance = new BusRoutesApi();
Integer ROUTE = 56; // Integer | Sepcify the Route ID as an integer.
Integer DIRECTION = 56; // Integer | Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)
try {
    Success result = apiInstance.getStops(ROUTE, DIRECTION);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BusRoutesApi#getStops");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ROUTE** | **Integer**| Sepcify the Route ID as an integer. |
 **DIRECTION** | **Integer**| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) |

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

<a name="getTimepointDepartures"></a>
# **getTimepointDepartures**
> TimePoints getTimepointDepartures(ROUTE, DIRECTION, STOP)



Returns the scheduled departures for a selected route, direction and timepoint stop.

### Example
```java
// Import classes:
//import io.swagger.client.api.BusRoutesApi;

BusRoutesApi apiInstance = new BusRoutesApi();
Integer ROUTE = 56; // Integer | Sepcify the Route ID as an integer.
Integer DIRECTION = 56; // Integer | Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)
String STOP = "STOP_example"; // String | Specify the value of the Bus Stop ID as an abbreviated string
try {
    TimePoints result = apiInstance.getTimepointDepartures(ROUTE, DIRECTION, STOP);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BusRoutesApi#getTimepointDepartures");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ROUTE** | **Integer**| Sepcify the Route ID as an integer. |
 **DIRECTION** | **Integer**| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) |
 **STOP** | **String**| Specify the value of the Bus Stop ID as an abbreviated string |

### Return type

[**TimePoints**](TimePoints.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

<a name="getVehicleLocations"></a>
# **getVehicleLocations**
> Success getVehicleLocations(ROUTE)



This operation returns a list of vehicles currently in service that have recently (within 5 minutes)  reported their locations. A route paramter is used to return results for the given route.  Use \&quot;0\&quot; for the route parameter to return a list of all vehicles in service.

### Example
```java
// Import classes:
//import io.swagger.client.api.BusRoutesApi;

BusRoutesApi apiInstance = new BusRoutesApi();
Integer ROUTE = 56; // Integer | Sepcify the Route ID as an integer.
try {
    Success result = apiInstance.getVehicleLocations(ROUTE);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BusRoutesApi#getVehicleLocations");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ROUTE** | **Integer**| Sepcify the Route ID as an integer. |

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

