# BusRouteInfoApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateroute**](BusRouteInfoApi.md#updateroute) | **POST** /NexTrip/update/{ROUTE} | 


<a name="updateroute"></a>
# **updateroute**
> RouteData updateroute(ROUTE)



Update a bus route

### Example
```java
// Import classes:
//import io.swagger.client.api.BusRouteInfoApi;

BusRouteInfoApi apiInstance = new BusRouteInfoApi();
Integer ROUTE = 56; // Integer | Sepcify the Route ID as an integer.
try {
    RouteData result = apiInstance.updateroute(ROUTE);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BusRouteInfoApi#updateroute");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ROUTE** | **Integer**| Sepcify the Route ID as an integer. |

### Return type

[**RouteData**](RouteData.md)

### Authorization

[admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

