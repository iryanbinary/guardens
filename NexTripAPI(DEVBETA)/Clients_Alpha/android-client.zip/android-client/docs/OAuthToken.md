
# OAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** |  |  [optional]
**refreshToken** | **String** |  |  [optional]
**tokenType** | **String** |  |  [optional]
**expiresIn** | **String** |  |  [optional]
**scopes** | **String** |  |  [optional]



