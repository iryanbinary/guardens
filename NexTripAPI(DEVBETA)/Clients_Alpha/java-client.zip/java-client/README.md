# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.AccessControlApi;

import java.io.File;
import java.util.*;

public class AccessControlApiExample {

    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        
        // Configure OAuth2 access token for authorization: AccessCode
        OAuth AccessCode = (OAuth) defaultClient.getAuthentication("AccessCode");
        AccessCode.setAccessToken("YOUR ACCESS TOKEN");

        // Configure OAuth2 access token for authorization: MobileApp_Implicit
        OAuth MobileApp_Implicit = (OAuth) defaultClient.getAuthentication("MobileApp_Implicit");
        MobileApp_Implicit.setAccessToken("YOUR ACCESS TOKEN");

        // Configure OAuth2 access token for authorization: admin_AccessCode
        OAuth admin_AccessCode = (OAuth) defaultClient.getAuthentication("admin_AccessCode");
        admin_AccessCode.setAccessToken("YOUR ACCESS TOKEN");

        AccessControlApi apiInstance = new AccessControlApi();
        String grantType = "grantType_example"; // String | value = authorization_code
        String clientId = "clientId_example"; // String | a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
        String redirectUri = "redirectUri_example"; // String | App Callback URI
        try {
            Success result = apiInstance.getAuthCode(grantType, clientId, redirectUri);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling AccessControlApi#getAuthCode");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *https://svc.metrotransit.org*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AccessControlApi* | [**getAuthCode**](docs/AccessControlApi.md#getAuthCode) | **GET** /NexTrip/oauth20/authorize | 
*AccessControlApi* | [**getTokenRequest**](docs/AccessControlApi.md#getTokenRequest) | **GET** /NexTrip/oauth20/token | 
*AccessControlApi* | [**postTokenRequest**](docs/AccessControlApi.md#postTokenRequest) | **POST** /NexTrip/oauth20/token | 
*BusRouteInfoApi* | [**updateroute**](docs/BusRouteInfoApi.md#updateroute) | **POST** /NexTrip/update/{ROUTE} | 
*BusRoutesApi* | [**getDepartures**](docs/BusRoutesApi.md#getDepartures) | **GET** /NexTrip/{STOPID} | 
*BusRoutesApi* | [**getDirections**](docs/BusRoutesApi.md#getDirections) | **GET** /NexTrip/Directions/{ROUTE} | 
*BusRoutesApi* | [**getProviders**](docs/BusRoutesApi.md#getProviders) | **GET** /NexTrip/Providers | 
*BusRoutesApi* | [**getRoutes**](docs/BusRoutesApi.md#getRoutes) | **GET** /NexTrip/Routes | 
*BusRoutesApi* | [**getStops**](docs/BusRoutesApi.md#getStops) | **GET** /NexTrip/Stops/{ROUTE}/{DIRECTION} | 
*BusRoutesApi* | [**getTimepointDepartures**](docs/BusRoutesApi.md#getTimepointDepartures) | **GET** /NexTrip/{ROUTE}/{DIRECTION}/{STOP} | 
*BusRoutesApi* | [**getVehicleLocations**](docs/BusRoutesApi.md#getVehicleLocations) | **GET** /NexTrip/VehicleLocations/{ROUTE} | 


## Documentation for Models

 - [Err](docs/Err.md)
 - [OAuthToken](docs/OAuthToken.md)
 - [RouteData](docs/RouteData.md)
 - [Success](docs/Success.md)
 - [TimePoints](docs/TimePoints.md)


## Documentation for Authorization

Authentication schemes defined for the API:
### AccessCode

- **Type**: OAuth
- **Flow**: accessCode
- **Authorization URL**: https://svc.metrotransit.org/oauth/authorize
- **Scopes**: 
  - routes:all: Grants read access to all routes
  - routes:express: Grants read access to only express routes
  - routes:local: Grants read access to local routes
  - readpublic_key: List and view details for public keys

### MobileApp_Implicit

- **Type**: OAuth
- **Flow**: implicit
- **Authorization URL**: https://svc.metrotransit.org/oauth/authorize
- **Scopes**: 
  - readpublic_key: List and view details for public keys

### admin_AccessCode

- **Type**: OAuth
- **Flow**: accessCode
- **Authorization URL**: https://svc.metrotransit.org/oauth/authorize
- **Scopes**: 
  - admin_updateroutes: Grants write access to routes data
  - admin_writepublic_key: Create, list, and view details for public keys
  - admin_public_key: Fully manage PKI keys


## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author



