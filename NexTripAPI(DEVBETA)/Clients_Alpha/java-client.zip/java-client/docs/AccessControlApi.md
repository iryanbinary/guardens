# AccessControlApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAuthCode**](AccessControlApi.md#getAuthCode) | **GET** /NexTrip/oauth20/authorize | 
[**getTokenRequest**](AccessControlApi.md#getTokenRequest) | **GET** /NexTrip/oauth20/token | 
[**postTokenRequest**](AccessControlApi.md#postTokenRequest) | **POST** /NexTrip/oauth20/token | 


<a name="getAuthCode"></a>
# **getAuthCode**
> Success getAuthCode(grantType, clientId, redirectUri)



Request a temporary code for the desired API Access Token Scope(s)

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AccessControlApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: AccessCode
OAuth AccessCode = (OAuth) defaultClient.getAuthentication("AccessCode");
AccessCode.setAccessToken("YOUR ACCESS TOKEN");

// Configure OAuth2 access token for authorization: MobileApp_Implicit
OAuth MobileApp_Implicit = (OAuth) defaultClient.getAuthentication("MobileApp_Implicit");
MobileApp_Implicit.setAccessToken("YOUR ACCESS TOKEN");

// Configure OAuth2 access token for authorization: admin_AccessCode
OAuth admin_AccessCode = (OAuth) defaultClient.getAuthentication("admin_AccessCode");
admin_AccessCode.setAccessToken("YOUR ACCESS TOKEN");

AccessControlApi apiInstance = new AccessControlApi();
String grantType = "grantType_example"; // String | value = authorization_code
String clientId = "clientId_example"; // String | a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
String redirectUri = "redirectUri_example"; // String | App Callback URI
try {
    Success result = apiInstance.getAuthCode(grantType, clientId, redirectUri);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccessControlApi#getAuthCode");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grantType** | **String**| value &#x3D; authorization_code |
 **clientId** | **String**| a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) |
 **redirectUri** | **String**| App Callback URI |

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

<a name="getTokenRequest"></a>
# **getTokenRequest**
> OAuthToken getTokenRequest(grantType, clientId, clientSecret)



Applications request an implicit token with a client id and secret prior to user authentication

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AccessControlApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: AccessCode
OAuth AccessCode = (OAuth) defaultClient.getAuthentication("AccessCode");
AccessCode.setAccessToken("YOUR ACCESS TOKEN");

// Configure OAuth2 access token for authorization: MobileApp_Implicit
OAuth MobileApp_Implicit = (OAuth) defaultClient.getAuthentication("MobileApp_Implicit");
MobileApp_Implicit.setAccessToken("YOUR ACCESS TOKEN");

// Configure OAuth2 access token for authorization: admin_AccessCode
OAuth admin_AccessCode = (OAuth) defaultClient.getAuthentication("admin_AccessCode");
admin_AccessCode.setAccessToken("YOUR ACCESS TOKEN");

AccessControlApi apiInstance = new AccessControlApi();
String grantType = "grantType_example"; // String | value = implicit
String clientId = "clientId_example"; // String | a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
String clientSecret = "clientSecret_example"; // String | the client secret associated to the app client id (this changes with each app store version iteration)
try {
    OAuthToken result = apiInstance.getTokenRequest(grantType, clientId, clientSecret);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccessControlApi#getTokenRequest");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grantType** | **String**| value &#x3D; implicit |
 **clientId** | **String**| a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) |
 **clientSecret** | **String**| the client secret associated to the app client id (this changes with each app store version iteration) |

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

<a name="postTokenRequest"></a>
# **postTokenRequest**
> OAuthToken postTokenRequest()



Authorization Code grant types require a POST to the token endpoint after a GET for Authorization code.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AccessControlApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: AccessCode
OAuth AccessCode = (OAuth) defaultClient.getAuthentication("AccessCode");
AccessCode.setAccessToken("YOUR ACCESS TOKEN");

// Configure OAuth2 access token for authorization: MobileApp_Implicit
OAuth MobileApp_Implicit = (OAuth) defaultClient.getAuthentication("MobileApp_Implicit");
MobileApp_Implicit.setAccessToken("YOUR ACCESS TOKEN");

// Configure OAuth2 access token for authorization: admin_AccessCode
OAuth admin_AccessCode = (OAuth) defaultClient.getAuthentication("admin_AccessCode");
admin_AccessCode.setAccessToken("YOUR ACCESS TOKEN");

AccessControlApi apiInstance = new AccessControlApi();
try {
    OAuthToken result = apiInstance.postTokenRequest();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccessControlApi#postTokenRequest");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

