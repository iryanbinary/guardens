
# TimePoints

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**actual** | **Boolean** |  |  [optional]
**blockNumber** | **Integer** |  |  [optional]
**departureText** | **String** |  |  [optional]
**departureTime** | **String** |  |  [optional]
**description** | **String** |  |  [optional]
**gate** | **String** |  |  [optional]
**route** | **Integer** |  |  [optional]
**routeDirection** | **String** |  |  [optional]
**terminal** | **String** |  |  [optional]
**vehicleHeading** | **Integer** |  |  [optional]
**vehicleLatitude** | **String** |  |  [optional]
**vehicleLongitude** | **String** |  |  [optional]



