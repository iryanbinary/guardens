
# RouteData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**route** | **Integer** |  |  [optional]
**providerID** | **Integer** |  |  [optional]
**description** | **String** |  |  [optional]



