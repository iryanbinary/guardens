# WWW::SwaggerClient::AccessControlApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::AccessControlApi;
```

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_auth_code**](AccessControlApi.md#get_auth_code) | **GET** /NexTrip/oauth20/authorize | 
[**get_token_request**](AccessControlApi.md#get_token_request) | **GET** /NexTrip/oauth20/token | 
[**post_token_request**](AccessControlApi.md#post_token_request) | **POST** /NexTrip/oauth20/token | 


# **get_auth_code**
> Success get_auth_code(grant_type => $grant_type, client_id => $client_id, redirect_uri => $redirect_uri)



Request a temporary code for the desired API Access Token Scope(s)

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::AccessControlApi;

# Configure OAuth2 access token for authorization: AccessCode
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';
# Configure OAuth2 access token for authorization: MobileApp_Implicit
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';
# Configure OAuth2 access token for authorization: admin_AccessCode
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::AccessControlApi->new();
my $grant_type = 'grant_type_example'; # string | value = authorization_code
my $client_id = 'client_id_example'; # string | a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
my $redirect_uri = 'redirect_uri_example'; # string | App Callback URI

eval { 
    my $result = $api_instance->get_auth_code(grant_type => $grant_type, client_id => $client_id, redirect_uri => $redirect_uri);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling AccessControlApi->get_auth_code: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grant_type** | **string**| value &#x3D; authorization_code | 
 **client_id** | **string**| a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) | 
 **redirect_uri** | **string**| App Callback URI | 

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_request**
> OAuthToken get_token_request(grant_type => $grant_type, client_id => $client_id, client_secret => $client_secret)



Applications request an implicit token with a client id and secret prior to user authentication

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::AccessControlApi;

# Configure OAuth2 access token for authorization: AccessCode
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';
# Configure OAuth2 access token for authorization: MobileApp_Implicit
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';
# Configure OAuth2 access token for authorization: admin_AccessCode
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::AccessControlApi->new();
my $grant_type = 'grant_type_example'; # string | value = implicit
my $client_id = 'client_id_example'; # string | a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
my $client_secret = 'client_secret_example'; # string | the client secret associated to the app client id (this changes with each app store version iteration)

eval { 
    my $result = $api_instance->get_token_request(grant_type => $grant_type, client_id => $client_id, client_secret => $client_secret);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling AccessControlApi->get_token_request: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grant_type** | **string**| value &#x3D; implicit | 
 **client_id** | **string**| a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) | 
 **client_secret** | **string**| the client secret associated to the app client id (this changes with each app store version iteration) | 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_token_request**
> OAuthToken post_token_request()



Authorization Code grant types require a POST to the token endpoint after a GET for Authorization code.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::AccessControlApi;

# Configure OAuth2 access token for authorization: AccessCode
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';
# Configure OAuth2 access token for authorization: MobileApp_Implicit
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';
# Configure OAuth2 access token for authorization: admin_AccessCode
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::AccessControlApi->new();

eval { 
    my $result = $api_instance->post_token_request();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling AccessControlApi->post_token_request: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

