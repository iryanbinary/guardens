# WWW::SwaggerClient::BusRouteInfoApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::BusRouteInfoApi;
```

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateroute**](BusRouteInfoApi.md#updateroute) | **POST** /NexTrip/update/{ROUTE} | 


# **updateroute**
> RouteData updateroute(route => $route)



Update a bus route

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::BusRouteInfoApi;

# Configure OAuth2 access token for authorization: admin_AccessCode
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::BusRouteInfoApi->new();
my $route = 56; # int | Sepcify the Route ID as an integer.

eval { 
    my $result = $api_instance->updateroute(route => $route);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling BusRouteInfoApi->updateroute: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. | 

### Return type

[**RouteData**](RouteData.md)

### Authorization

[admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

