# WWW::SwaggerClient::Object::TimePoints

## Load the model package
```perl
use WWW::SwaggerClient::Object::TimePoints;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **int** |  | [optional] 
**actual** | **boolean** |  | [optional] 
**block_number** | **int** |  | [optional] 
**departure_text** | **string** |  | [optional] 
**departure_time** | **string** |  | [optional] 
**description** | **string** |  | [optional] 
**gate** | **string** |  | [optional] 
**route** | **int** |  | [optional] 
**route_direction** | **string** |  | [optional] 
**terminal** | **string** |  | [optional] 
**vehicle_heading** | **int** |  | [optional] 
**vehicle_latitude** | **string** |  | [optional] 
**vehicle_longitude** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


