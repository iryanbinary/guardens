function New-OAuthToken {
    [CmdletBinding()]
    Param (
        [Parameter(Position = 0, ValueFromPipelineByPropertyName = $true)]
        [String]
        ${token},
        [Parameter(Position = 0, ValueFromPipelineByPropertyName = $true)]
        [String]
        ${refresh_token},
        [Parameter(Position = 0, ValueFromPipelineByPropertyName = $true)]
        [String]
        ${token_type},
        [Parameter(Position = 0, ValueFromPipelineByPropertyName = $true)]
        [String]
        ${expires_in},
        [Parameter(Position = 0, ValueFromPipelineByPropertyName = $true)]
        [String]
        ${scopes}
    )

    Process {
        'Creating object: IO.Swagger.Model.OAuthToken' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        New-Object -TypeName IO.Swagger.Model.OAuthToken -ArgumentList @(
            ${token},
            ${refresh_token},
            ${token_type},
            ${expires_in},
            ${scopes}
        )
    }
}
