function Invoke-AccessControlApiGetAuthCode {
    [CmdletBinding()]
    Param (
        [Parameter(Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [String]
        ${grantType},
        [Parameter(Position = 1, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [String]
        ${clientId},
        [Parameter(Position = 2, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [String]
        ${redirectUri}
    )

    Process {
        'Calling method: AccessControlApi-GetAuthCode' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        $Script:AccessControlApi.GetAuthCode(
            ${grantType},
            ${clientId},
            ${redirectUri}
        )
    }
}

function Invoke-AccessControlApiGetTokenRequest {
    [CmdletBinding()]
    Param (
        [Parameter(Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [String]
        ${grantType},
        [Parameter(Position = 1, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [String]
        ${clientId},
        [Parameter(Position = 2, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [String]
        ${clientSecret}
    )

    Process {
        'Calling method: AccessControlApi-GetTokenRequest' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        $Script:AccessControlApi.GetTokenRequest(
            ${grantType},
            ${clientId},
            ${clientSecret}
        )
    }
}

function Invoke-AccessControlApiPostTokenRequest {
    [CmdletBinding()]
    Param (
    )

    Process {
        'Calling method: AccessControlApi-PostTokenRequest' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        $Script:AccessControlApi.PostTokenRequest(
        )
    }
}

