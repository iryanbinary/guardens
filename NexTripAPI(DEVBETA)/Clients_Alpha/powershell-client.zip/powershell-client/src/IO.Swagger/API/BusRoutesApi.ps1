function Invoke-BusRoutesApiGetDepartures {
    [CmdletBinding()]
    Param (
        [Parameter(Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [String]
        ${sTOPID}
    )

    Process {
        'Calling method: BusRoutesApi-GetDepartures' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        $Script:BusRoutesApi.GetDepartures(
            ${sTOPID}
        )
    }
}

function Invoke-BusRoutesApiGetDirections {
    [CmdletBinding()]
    Param (
        [Parameter(Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [Int32]
        ${rOUTE}
    )

    Process {
        'Calling method: BusRoutesApi-GetDirections' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        $Script:BusRoutesApi.GetDirections(
            ${rOUTE}
        )
    }
}

function Invoke-BusRoutesApiGetProviders {
    [CmdletBinding()]
    Param (
    )

    Process {
        'Calling method: BusRoutesApi-GetProviders' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        $Script:BusRoutesApi.GetProviders(
        )
    }
}

function Invoke-BusRoutesApiGetRoutes {
    [CmdletBinding()]
    Param (
    )

    Process {
        'Calling method: BusRoutesApi-GetRoutes' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        $Script:BusRoutesApi.GetRoutes(
        )
    }
}

function Invoke-BusRoutesApiGetStops {
    [CmdletBinding()]
    Param (
        [Parameter(Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [Int32]
        ${rOUTE},
        [Parameter(Position = 1, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [Int32]
        ${dIRECTION}
    )

    Process {
        'Calling method: BusRoutesApi-GetStops' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        $Script:BusRoutesApi.GetStops(
            ${rOUTE},
            ${dIRECTION}
        )
    }
}

function Invoke-BusRoutesApiGetTimepointDepartures {
    [CmdletBinding()]
    Param (
        [Parameter(Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [Int32]
        ${rOUTE},
        [Parameter(Position = 1, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [Int32]
        ${dIRECTION},
        [Parameter(Position = 2, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [String]
        ${sTOP}
    )

    Process {
        'Calling method: BusRoutesApi-GetTimepointDepartures' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        $Script:BusRoutesApi.GetTimepointDepartures(
            ${rOUTE},
            ${dIRECTION},
            ${sTOP}
        )
    }
}

function Invoke-BusRoutesApiGetVehicleLocations {
    [CmdletBinding()]
    Param (
        [Parameter(Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [Int32]
        ${rOUTE}
    )

    Process {
        'Calling method: BusRoutesApi-GetVehicleLocations' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        $Script:BusRoutesApi.GetVehicleLocations(
            ${rOUTE}
        )
    }
}

