function Invoke-BusRouteInfoApiUpdateroute {
    [CmdletBinding()]
    Param (
        [Parameter(Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [Int32]
        ${rOUTE}
    )

    Process {
        'Calling method: BusRouteInfoApi-Updateroute' | Write-Verbose
        $PSBoundParameters | Out-DebugParameter | Write-Debug

        $Script:BusRouteInfoApi.Updateroute(
            ${rOUTE}
        )
    }
}

