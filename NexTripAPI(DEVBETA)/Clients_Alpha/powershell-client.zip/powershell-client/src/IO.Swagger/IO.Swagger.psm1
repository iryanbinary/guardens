#region Import functions

'API', 'Model', 'Private' | Get-ChildItem -Path {
    Join-Path $PSScriptRoot $_
} -Filter '*.ps1' | ForEach-Object {
    Write-Verbose "Importing file: $($_.BaseName)"
    try {
        . $_.FullName
    } catch {
        Write-Verbose "Can't import function!"
    }
}

#endregion


#region Initialize APIs

'Creating object: IO.Swagger.Api.AccessControlApi' | Write-Verbose
$Script:AccessControlApi= New-Object -TypeName IO.Swagger.Api.AccessControlApi -ArgumentList @($null)

'Creating object: IO.Swagger.Api.BusRouteInfoApi' | Write-Verbose
$Script:BusRouteInfoApi= New-Object -TypeName IO.Swagger.Api.BusRouteInfoApi -ArgumentList @($null)

'Creating object: IO.Swagger.Api.BusRoutesApi' | Write-Verbose
$Script:BusRoutesApi= New-Object -TypeName IO.Swagger.Api.BusRoutesApi -ArgumentList @($null)


#endregion
