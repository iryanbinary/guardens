## TODO we need to update the template to test the model files

