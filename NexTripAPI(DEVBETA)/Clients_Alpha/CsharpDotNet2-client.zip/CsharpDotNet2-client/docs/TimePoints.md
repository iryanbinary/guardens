# IO.Swagger.Model.TimePoints
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | **int?** |  | [optional] 
**Actual** | **bool?** |  | [optional] 
**BlockNumber** | **int?** |  | [optional] 
**DepartureText** | **string** |  | [optional] 
**DepartureTime** | **string** |  | [optional] 
**Description** | **string** |  | [optional] 
**Gate** | **string** |  | [optional] 
**Route** | **int?** |  | [optional] 
**RouteDirection** | **string** |  | [optional] 
**Terminal** | **string** |  | [optional] 
**VehicleHeading** | **int?** |  | [optional] 
**VehicleLatitude** | **string** |  | [optional] 
**VehicleLongitude** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

