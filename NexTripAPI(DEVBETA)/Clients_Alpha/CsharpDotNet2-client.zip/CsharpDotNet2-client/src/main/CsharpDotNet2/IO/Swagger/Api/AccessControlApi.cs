using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IAccessControlApi
    {
        /// <summary>
        ///  Request a temporary code for the desired API Access Token Scope(s)
        /// </summary>
        /// <param name="grantType">value &#x3D; authorization_code</param>
        /// <param name="clientId">a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)</param>
        /// <param name="redirectUri">App Callback URI</param>
        /// <returns>Success</returns>
        Success GetAuthCode (string grantType, string clientId, string redirectUri);
        /// <summary>
        ///  Applications request an implicit token with a client id and secret prior to user authentication
        /// </summary>
        /// <param name="grantType">value &#x3D; implicit</param>
        /// <param name="clientId">a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)</param>
        /// <param name="clientSecret">the client secret associated to the app client id (this changes with each app store version iteration)</param>
        /// <returns>OAuthToken</returns>
        OAuthToken GetTokenRequest (string grantType, string clientId, string clientSecret);
        /// <summary>
        ///  Authorization Code grant types require a POST to the token endpoint after a GET for Authorization code.
        /// </summary>
        /// <returns>OAuthToken</returns>
        OAuthToken PostTokenRequest ();
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class AccessControlApi : IAccessControlApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AccessControlApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public AccessControlApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="AccessControlApi"/> class.
        /// </summary>
        /// <returns></returns>
        public AccessControlApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        ///  Request a temporary code for the desired API Access Token Scope(s)
        /// </summary>
        /// <param name="grantType">value &#x3D; authorization_code</param> 
        /// <param name="clientId">a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)</param> 
        /// <param name="redirectUri">App Callback URI</param> 
        /// <returns>Success</returns>            
        public Success GetAuthCode (string grantType, string clientId, string redirectUri)
        {
            
            // verify the required parameter 'grantType' is set
            if (grantType == null) throw new ApiException(400, "Missing required parameter 'grantType' when calling GetAuthCode");
            
            // verify the required parameter 'clientId' is set
            if (clientId == null) throw new ApiException(400, "Missing required parameter 'clientId' when calling GetAuthCode");
            
            // verify the required parameter 'redirectUri' is set
            if (redirectUri == null) throw new ApiException(400, "Missing required parameter 'redirectUri' when calling GetAuthCode");
            
    
            var path = "/NexTrip/oauth20/authorize";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (grantType != null) queryParams.Add("grant_type", ApiClient.ParameterToString(grantType)); // query parameter
 if (clientId != null) queryParams.Add("client_id", ApiClient.ParameterToString(clientId)); // query parameter
 if (redirectUri != null) queryParams.Add("redirect_uri", ApiClient.ParameterToString(redirectUri)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "AccessCode", "MobileApp_Implicit", "admin_AccessCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetAuthCode: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetAuthCode: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Success) ApiClient.Deserialize(response.Content, typeof(Success), response.Headers);
        }
    
        /// <summary>
        ///  Applications request an implicit token with a client id and secret prior to user authentication
        /// </summary>
        /// <param name="grantType">value &#x3D; implicit</param> 
        /// <param name="clientId">a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)</param> 
        /// <param name="clientSecret">the client secret associated to the app client id (this changes with each app store version iteration)</param> 
        /// <returns>OAuthToken</returns>            
        public OAuthToken GetTokenRequest (string grantType, string clientId, string clientSecret)
        {
            
            // verify the required parameter 'grantType' is set
            if (grantType == null) throw new ApiException(400, "Missing required parameter 'grantType' when calling GetTokenRequest");
            
            // verify the required parameter 'clientId' is set
            if (clientId == null) throw new ApiException(400, "Missing required parameter 'clientId' when calling GetTokenRequest");
            
            // verify the required parameter 'clientSecret' is set
            if (clientSecret == null) throw new ApiException(400, "Missing required parameter 'clientSecret' when calling GetTokenRequest");
            
    
            var path = "/NexTrip/oauth20/token";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (grantType != null) queryParams.Add("grant_type", ApiClient.ParameterToString(grantType)); // query parameter
 if (clientId != null) queryParams.Add("client_id", ApiClient.ParameterToString(clientId)); // query parameter
 if (clientSecret != null) queryParams.Add("client_secret", ApiClient.ParameterToString(clientSecret)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "AccessCode", "MobileApp_Implicit", "admin_AccessCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetTokenRequest: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetTokenRequest: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OAuthToken) ApiClient.Deserialize(response.Content, typeof(OAuthToken), response.Headers);
        }
    
        /// <summary>
        ///  Authorization Code grant types require a POST to the token endpoint after a GET for Authorization code.
        /// </summary>
        /// <returns>OAuthToken</returns>            
        public OAuthToken PostTokenRequest ()
        {
            
    
            var path = "/NexTrip/oauth20/token";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "AccessCode", "MobileApp_Implicit", "admin_AccessCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PostTokenRequest: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PostTokenRequest: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OAuthToken) ApiClient.Deserialize(response.Content, typeof(OAuthToken), response.Headers);
        }
    
    }
}
