using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class TimePoints {
    /// <summary>
    /// Gets or Sets Code
    /// </summary>
    [DataMember(Name="code", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "code")]
    public int? Code { get; set; }

    /// <summary>
    /// Gets or Sets Actual
    /// </summary>
    [DataMember(Name="Actual", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Actual")]
    public bool? Actual { get; set; }

    /// <summary>
    /// Gets or Sets BlockNumber
    /// </summary>
    [DataMember(Name="BlockNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "BlockNumber")]
    public int? BlockNumber { get; set; }

    /// <summary>
    /// Gets or Sets DepartureText
    /// </summary>
    [DataMember(Name="DepartureText", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DepartureText")]
    public string DepartureText { get; set; }

    /// <summary>
    /// Gets or Sets DepartureTime
    /// </summary>
    [DataMember(Name="DepartureTime", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DepartureTime")]
    public string DepartureTime { get; set; }

    /// <summary>
    /// Gets or Sets Description
    /// </summary>
    [DataMember(Name="Description", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Description")]
    public string Description { get; set; }

    /// <summary>
    /// Gets or Sets Gate
    /// </summary>
    [DataMember(Name="Gate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Gate")]
    public string Gate { get; set; }

    /// <summary>
    /// Gets or Sets Route
    /// </summary>
    [DataMember(Name="Route", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Route")]
    public int? Route { get; set; }

    /// <summary>
    /// Gets or Sets RouteDirection
    /// </summary>
    [DataMember(Name="RouteDirection", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "RouteDirection")]
    public string RouteDirection { get; set; }

    /// <summary>
    /// Gets or Sets Terminal
    /// </summary>
    [DataMember(Name="Terminal", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Terminal")]
    public string Terminal { get; set; }

    /// <summary>
    /// Gets or Sets VehicleHeading
    /// </summary>
    [DataMember(Name="VehicleHeading", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "VehicleHeading")]
    public int? VehicleHeading { get; set; }

    /// <summary>
    /// Gets or Sets VehicleLatitude
    /// </summary>
    [DataMember(Name="VehicleLatitude", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "VehicleLatitude")]
    public string VehicleLatitude { get; set; }

    /// <summary>
    /// Gets or Sets VehicleLongitude
    /// </summary>
    [DataMember(Name="VehicleLongitude", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "VehicleLongitude")]
    public string VehicleLongitude { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class TimePoints {\n");
      sb.Append("  Code: ").Append(Code).Append("\n");
      sb.Append("  Actual: ").Append(Actual).Append("\n");
      sb.Append("  BlockNumber: ").Append(BlockNumber).Append("\n");
      sb.Append("  DepartureText: ").Append(DepartureText).Append("\n");
      sb.Append("  DepartureTime: ").Append(DepartureTime).Append("\n");
      sb.Append("  Description: ").Append(Description).Append("\n");
      sb.Append("  Gate: ").Append(Gate).Append("\n");
      sb.Append("  Route: ").Append(Route).Append("\n");
      sb.Append("  RouteDirection: ").Append(RouteDirection).Append("\n");
      sb.Append("  Terminal: ").Append(Terminal).Append("\n");
      sb.Append("  VehicleHeading: ").Append(VehicleHeading).Append("\n");
      sb.Append("  VehicleLatitude: ").Append(VehicleLatitude).Append("\n");
      sb.Append("  VehicleLongitude: ").Append(VehicleLongitude).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
