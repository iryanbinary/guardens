using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IBusRoutesApi
    {
        /// <summary>
        ///  Returns a list of departures scheduled for any given bus stop.
        /// </summary>
        /// <param name="STOPID">Specify the value of the Bus Stop ID as an abbreviated string</param>
        /// <returns>Success</returns>
        Success GetDepartures (string STOPID);
        /// <summary>
        ///  Returns the two directions that are valid for a given route.
        /// </summary>
        /// <param name="ROUTE">Sepcify the Route ID as an integer.</param>
        /// <returns>Success</returns>
        Success GetDirections (int? ROUTE);
        /// <summary>
        ///  Returns a list of area Transit providers.  Providers are identified in the list of Routes allowing routes to be selected for a single provider. 
        /// </summary>
        /// <returns>Success</returns>
        Success GetProviders ();
        /// <summary>
        ///  Returns a list of Transit routes that are in service on the current day.
        /// </summary>
        /// <returns>RouteData</returns>
        RouteData GetRoutes ();
        /// <summary>
        ///  Returns a list of Timepoint stops for the given Route/Direction.
        /// </summary>
        /// <param name="ROUTE">Sepcify the Route ID as an integer.</param>
        /// <param name="DIRECTION">Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)</param>
        /// <returns>Success</returns>
        Success GetStops (int? ROUTE, int? DIRECTION);
        /// <summary>
        ///  Returns the scheduled departures for a selected route, direction and timepoint stop.
        /// </summary>
        /// <param name="ROUTE">Sepcify the Route ID as an integer.</param>
        /// <param name="DIRECTION">Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)</param>
        /// <param name="STOP">Specify the value of the Bus Stop ID as an abbreviated string</param>
        /// <returns>TimePoints</returns>
        TimePoints GetTimepointDepartures (int? ROUTE, int? DIRECTION, string STOP);
        /// <summary>
        ///  This operation returns a list of vehicles currently in service that have recently (within 5 minutes)  reported their locations. A route paramter is used to return results for the given route.  Use \&quot;0\&quot; for the route parameter to return a list of all vehicles in service.
        /// </summary>
        /// <param name="ROUTE">Sepcify the Route ID as an integer.</param>
        /// <returns>Success</returns>
        Success GetVehicleLocations (int? ROUTE);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class BusRoutesApi : IBusRoutesApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BusRoutesApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public BusRoutesApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="BusRoutesApi"/> class.
        /// </summary>
        /// <returns></returns>
        public BusRoutesApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        ///  Returns a list of departures scheduled for any given bus stop.
        /// </summary>
        /// <param name="STOPID">Specify the value of the Bus Stop ID as an abbreviated string</param> 
        /// <returns>Success</returns>            
        public Success GetDepartures (string STOPID)
        {
            
            // verify the required parameter 'STOPID' is set
            if (STOPID == null) throw new ApiException(400, "Missing required parameter 'STOPID' when calling GetDepartures");
            
    
            var path = "/NexTrip/{STOPID}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "STOPID" + "}", ApiClient.ParameterToString(STOPID));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "AccessCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetDepartures: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetDepartures: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Success) ApiClient.Deserialize(response.Content, typeof(Success), response.Headers);
        }
    
        /// <summary>
        ///  Returns the two directions that are valid for a given route.
        /// </summary>
        /// <param name="ROUTE">Sepcify the Route ID as an integer.</param> 
        /// <returns>Success</returns>            
        public Success GetDirections (int? ROUTE)
        {
            
            // verify the required parameter 'ROUTE' is set
            if (ROUTE == null) throw new ApiException(400, "Missing required parameter 'ROUTE' when calling GetDirections");
            
    
            var path = "/NexTrip/Directions/{ROUTE}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "ROUTE" + "}", ApiClient.ParameterToString(ROUTE));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "AccessCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetDirections: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetDirections: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Success) ApiClient.Deserialize(response.Content, typeof(Success), response.Headers);
        }
    
        /// <summary>
        ///  Returns a list of area Transit providers.  Providers are identified in the list of Routes allowing routes to be selected for a single provider. 
        /// </summary>
        /// <returns>Success</returns>            
        public Success GetProviders ()
        {
            
    
            var path = "/NexTrip/Providers";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "AccessCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetProviders: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetProviders: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Success) ApiClient.Deserialize(response.Content, typeof(Success), response.Headers);
        }
    
        /// <summary>
        ///  Returns a list of Transit routes that are in service on the current day.
        /// </summary>
        /// <returns>RouteData</returns>            
        public RouteData GetRoutes ()
        {
            
    
            var path = "/NexTrip/Routes";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "AccessCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetRoutes: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetRoutes: " + response.ErrorMessage, response.ErrorMessage);
    
            return (RouteData) ApiClient.Deserialize(response.Content, typeof(RouteData), response.Headers);
        }
    
        /// <summary>
        ///  Returns a list of Timepoint stops for the given Route/Direction.
        /// </summary>
        /// <param name="ROUTE">Sepcify the Route ID as an integer.</param> 
        /// <param name="DIRECTION">Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)</param> 
        /// <returns>Success</returns>            
        public Success GetStops (int? ROUTE, int? DIRECTION)
        {
            
            // verify the required parameter 'ROUTE' is set
            if (ROUTE == null) throw new ApiException(400, "Missing required parameter 'ROUTE' when calling GetStops");
            
            // verify the required parameter 'DIRECTION' is set
            if (DIRECTION == null) throw new ApiException(400, "Missing required parameter 'DIRECTION' when calling GetStops");
            
    
            var path = "/NexTrip/Stops/{ROUTE}/{DIRECTION}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "ROUTE" + "}", ApiClient.ParameterToString(ROUTE));
path = path.Replace("{" + "DIRECTION" + "}", ApiClient.ParameterToString(DIRECTION));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "AccessCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetStops: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetStops: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Success) ApiClient.Deserialize(response.Content, typeof(Success), response.Headers);
        }
    
        /// <summary>
        ///  Returns the scheduled departures for a selected route, direction and timepoint stop.
        /// </summary>
        /// <param name="ROUTE">Sepcify the Route ID as an integer.</param> 
        /// <param name="DIRECTION">Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)</param> 
        /// <param name="STOP">Specify the value of the Bus Stop ID as an abbreviated string</param> 
        /// <returns>TimePoints</returns>            
        public TimePoints GetTimepointDepartures (int? ROUTE, int? DIRECTION, string STOP)
        {
            
            // verify the required parameter 'ROUTE' is set
            if (ROUTE == null) throw new ApiException(400, "Missing required parameter 'ROUTE' when calling GetTimepointDepartures");
            
            // verify the required parameter 'DIRECTION' is set
            if (DIRECTION == null) throw new ApiException(400, "Missing required parameter 'DIRECTION' when calling GetTimepointDepartures");
            
            // verify the required parameter 'STOP' is set
            if (STOP == null) throw new ApiException(400, "Missing required parameter 'STOP' when calling GetTimepointDepartures");
            
    
            var path = "/NexTrip/{ROUTE}/{DIRECTION}/{STOP}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "ROUTE" + "}", ApiClient.ParameterToString(ROUTE));
path = path.Replace("{" + "DIRECTION" + "}", ApiClient.ParameterToString(DIRECTION));
path = path.Replace("{" + "STOP" + "}", ApiClient.ParameterToString(STOP));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "AccessCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetTimepointDepartures: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetTimepointDepartures: " + response.ErrorMessage, response.ErrorMessage);
    
            return (TimePoints) ApiClient.Deserialize(response.Content, typeof(TimePoints), response.Headers);
        }
    
        /// <summary>
        ///  This operation returns a list of vehicles currently in service that have recently (within 5 minutes)  reported their locations. A route paramter is used to return results for the given route.  Use \&quot;0\&quot; for the route parameter to return a list of all vehicles in service.
        /// </summary>
        /// <param name="ROUTE">Sepcify the Route ID as an integer.</param> 
        /// <returns>Success</returns>            
        public Success GetVehicleLocations (int? ROUTE)
        {
            
            // verify the required parameter 'ROUTE' is set
            if (ROUTE == null) throw new ApiException(400, "Missing required parameter 'ROUTE' when calling GetVehicleLocations");
            
    
            var path = "/NexTrip/VehicleLocations/{ROUTE}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "ROUTE" + "}", ApiClient.ParameterToString(ROUTE));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "AccessCode" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetVehicleLocations: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetVehicleLocations: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Success) ApiClient.Deserialize(response.Content, typeof(Success), response.Headers);
        }
    
    }
}
