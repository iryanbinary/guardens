# coding: utf-8

from __future__ import absolute_import

from swagger_server.models.err import Err
from swagger_server.models.route_data import RouteData
from swagger_server.models.success import Success
from swagger_server.models.time_points import TimePoints
from . import BaseTestCase
from six import BytesIO
from flask import json


class TestBusRoutesController(BaseTestCase):
    """ BusRoutesController integration test stubs """

    def test_get_departures(self):
        """
        Test case for get_departures

        
        """
        response = self.client.open('//NexTrip/{STOPID}'.format(STOPID='STOPID_example'),
                                    method='GET',
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_get_directions(self):
        """
        Test case for get_directions

        
        """
        response = self.client.open('//NexTrip/Directions/{ROUTE}'.format(ROUTE=56),
                                    method='GET',
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_get_providers(self):
        """
        Test case for get_providers

        
        """
        response = self.client.open('//NexTrip/Providers',
                                    method='GET',
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_get_routes(self):
        """
        Test case for get_routes

        
        """
        response = self.client.open('//NexTrip/Routes',
                                    method='GET',
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_get_stops(self):
        """
        Test case for get_stops

        
        """
        response = self.client.open('//NexTrip/Stops/{ROUTE}/{DIRECTION}'.format(ROUTE=56, DIRECTION=56),
                                    method='GET',
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_get_timepoint_departures(self):
        """
        Test case for get_timepoint_departures

        
        """
        response = self.client.open('//NexTrip/{ROUTE}/{DIRECTION}/{STOP}'.format(ROUTE=56, DIRECTION=56, STOP='STOP_example'),
                                    method='GET',
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_get_vehicle_locations(self):
        """
        Test case for get_vehicle_locations

        
        """
        response = self.client.open('//NexTrip/VehicleLocations/{ROUTE}'.format(ROUTE=56),
                                    method='GET',
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
