# coding: utf-8

from __future__ import absolute_import

from swagger_server.models.err import Err
from swagger_server.models.route_data import RouteData
from . import BaseTestCase
from six import BytesIO
from flask import json


class TestBusRouteInfoController(BaseTestCase):
    """ BusRouteInfoController integration test stubs """

    def test_updateroute(self):
        """
        Test case for updateroute

        
        """
        response = self.client.open('//NexTrip/update/{ROUTE}'.format(ROUTE=56),
                                    method='POST',
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
