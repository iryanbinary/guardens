import connexion
from swagger_server.models.err import Err
from swagger_server.models.o_auth_token import OAuthToken
from swagger_server.models.success import Success
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def get_auth_code(grant_type, client_id, redirect_uri):
    """
    get_auth_code
    Request a temporary code for the desired API Access Token Scope(s)
    :param grant_type: value &#x3D; authorization_code
    :type grant_type: str
    :param client_id: a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
    :type client_id: str
    :param redirect_uri: App Callback URI
    :type redirect_uri: str

    :rtype: Success
    """
    return 'do some magic!'


def get_token_request(grant_type, client_id, client_secret):
    """
    get_token_request
    Applications request an implicit token with a client id and secret prior to user authentication
    :param grant_type: value &#x3D; implicit
    :type grant_type: str
    :param client_id: a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
    :type client_id: str
    :param client_secret: the client secret associated to the app client id (this changes with each app store version iteration)
    :type client_secret: str

    :rtype: OAuthToken
    """
    return 'do some magic!'


def post_token_request():
    """
    post_token_request
    Authorization Code grant types require a POST to the token endpoint after a GET for Authorization code.

    :rtype: OAuthToken
    """
    return 'do some magic!'
