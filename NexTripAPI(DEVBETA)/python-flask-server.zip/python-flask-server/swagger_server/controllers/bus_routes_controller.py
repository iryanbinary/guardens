import connexion
from swagger_server.models.err import Err
from swagger_server.models.route_data import RouteData
from swagger_server.models.success import Success
from swagger_server.models.time_points import TimePoints
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def get_departures(STOPID):
    """
    get_departures
    Returns a list of departures scheduled for any given bus stop.
    :param STOPID: Specify the value of the Bus Stop ID as an abbreviated string
    :type STOPID: str

    :rtype: Success
    """
    return 'do some magic!'


def get_directions(ROUTE):
    """
    get_directions
    Returns the two directions that are valid for a given route.
    :param ROUTE: Sepcify the Route ID as an integer.
    :type ROUTE: int

    :rtype: Success
    """
    return 'do some magic!'


def get_providers():
    """
    get_providers
    Returns a list of area Transit providers.  Providers are identified in the list of Routes allowing routes to be selected for a single provider. 

    :rtype: Success
    """
    return 'do some magic!'


def get_routes():
    """
    get_routes
    Returns a list of Transit routes that are in service on the current day.

    :rtype: RouteData
    """
    return 'do some magic!'


def get_stops(ROUTE, DIRECTION):
    """
    get_stops
    Returns a list of Timepoint stops for the given Route/Direction.
    :param ROUTE: Sepcify the Route ID as an integer.
    :type ROUTE: int
    :param DIRECTION: Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)
    :type DIRECTION: int

    :rtype: Success
    """
    return 'do some magic!'


def get_timepoint_departures(ROUTE, DIRECTION, STOP):
    """
    get_timepoint_departures
    Returns the scheduled departures for a selected route, direction and timepoint stop.
    :param ROUTE: Sepcify the Route ID as an integer.
    :type ROUTE: int
    :param DIRECTION: Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)
    :type DIRECTION: int
    :param STOP: Specify the value of the Bus Stop ID as an abbreviated string
    :type STOP: str

    :rtype: TimePoints
    """
    return 'do some magic!'


def get_vehicle_locations(ROUTE):
    """
    get_vehicle_locations
    This operation returns a list of vehicles currently in service that have recently (within 5 minutes)  reported their locations. A route paramter is used to return results for the given route.  Use \&quot;0\&quot; for the route parameter to return a list of all vehicles in service.
    :param ROUTE: Sepcify the Route ID as an integer.
    :type ROUTE: int

    :rtype: Success
    """
    return 'do some magic!'
