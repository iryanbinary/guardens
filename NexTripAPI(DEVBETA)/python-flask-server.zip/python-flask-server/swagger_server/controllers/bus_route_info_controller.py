import connexion
from swagger_server.models.err import Err
from swagger_server.models.route_data import RouteData
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def updateroute(ROUTE):
    """
    updateroute
    Update a bus route
    :param ROUTE: Sepcify the Route ID as an integer.
    :type ROUTE: int

    :rtype: RouteData
    """
    return 'do some magic!'
