# SwaggerClient::RouteData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  | [optional] 
**route** | **Integer** |  | [optional] 
**provider_id** | **Integer** |  | [optional] 
**description** | **String** |  | [optional] 


