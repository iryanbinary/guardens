# SwaggerClient::OAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** |  | [optional] 
**refresh_token** | **String** |  | [optional] 
**token_type** | **String** |  | [optional] 
**expires_in** | **String** |  | [optional] 
**scopes** | **String** |  | [optional] 


