# SwaggerClient::TimePoints

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  | [optional] 
**actual** | **BOOLEAN** |  | [optional] 
**block_number** | **Integer** |  | [optional] 
**departure_text** | **String** |  | [optional] 
**departure_time** | **String** |  | [optional] 
**description** | **String** |  | [optional] 
**gate** | **String** |  | [optional] 
**route** | **Integer** |  | [optional] 
**route_direction** | **String** |  | [optional] 
**terminal** | **String** |  | [optional] 
**vehicle_heading** | **Integer** |  | [optional] 
**vehicle_latitude** | **String** |  | [optional] 
**vehicle_longitude** | **String** |  | [optional] 


