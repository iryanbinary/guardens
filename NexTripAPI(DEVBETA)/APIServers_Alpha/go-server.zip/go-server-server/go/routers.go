package 

import (
	"net/http"
	"fmt"
	"github.com/gorilla/mux"
)

type Route struct {
	Name        string
	Method      string
	Pattern     string
	HandlerFunc http.HandlerFunc
}

type Routes []Route

func NewRouter() *mux.Router {
	router := mux.NewRouter().StrictSlash(true)
	for _, route := range routes {
		var handler http.Handler
		handler = route.HandlerFunc
		handler = Logger(handler, route.Name)

		router.
			Methods(route.Method).
			Path(route.Pattern).
			Name(route.Name).
			Handler(handler)
	}

	return router
}

func Index(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Hello World!")
}

var routes = Routes{
	Route{
		"Index",
		"GET",
		"//",
		Index,
	},

	Route{
		"GetAuthCode",
		"GET",
		"//NexTrip/oauth20/authorize",
		GetAuthCode,
	},

	Route{
		"GetTokenRequest",
		"GET",
		"//NexTrip/oauth20/token",
		GetTokenRequest,
	},

	Route{
		"PostTokenRequest",
		"POST",
		"//NexTrip/oauth20/token",
		PostTokenRequest,
	},

	Route{
		"Updateroute",
		"POST",
		"//NexTrip/update/{ROUTE}",
		Updateroute,
	},

	Route{
		"GetDepartures",
		"GET",
		"//NexTrip/{STOPID}",
		GetDepartures,
	},

	Route{
		"GetDirections",
		"GET",
		"//NexTrip/Directions/{ROUTE}",
		GetDirections,
	},

	Route{
		"GetProviders",
		"GET",
		"//NexTrip/Providers",
		GetProviders,
	},

	Route{
		"GetRoutes",
		"GET",
		"//NexTrip/Routes",
		GetRoutes,
	},

	Route{
		"GetStops",
		"GET",
		"//NexTrip/Stops/{ROUTE}/{DIRECTION}",
		GetStops,
	},

	Route{
		"GetTimepointDepartures",
		"GET",
		"//NexTrip/{ROUTE}/{DIRECTION}/{STOP}",
		GetTimepointDepartures,
	},

	Route{
		"GetVehicleLocations",
		"GET",
		"//NexTrip/VehicleLocations/{ROUTE}",
		GetVehicleLocations,
	},

}
