# Swagger\Server\Api\AccessControlApiInterface

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAuthCode**](AccessControlApiInterface.md#getAuthCode) | **GET** /NexTrip/oauth20/authorize | 
[**getTokenRequest**](AccessControlApiInterface.md#getTokenRequest) | **GET** /NexTrip/oauth20/token | 
[**postTokenRequest**](AccessControlApiInterface.md#postTokenRequest) | **POST** /NexTrip/oauth20/token | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.accessControl:
        class: Acme\MyBundle\Api\AccessControlApi
        tags:
            - { name: "swagger_server.api", api: "accessControl" }
    # ...
```

## **getAuthCode**
> Swagger\Server\Model\Success getAuthCode($grant_type, $client_id, $redirect_uri)



Request a temporary code for the desired API Access Token Scope(s)

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/AccessControlApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\AccessControlApiInterface;

class AccessControlApi implements AccessControlApiInterface
{

    /**
     * Configure OAuth2 access token for authorization: AccessCode
     */
    public function setAccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    /**
     * Configure OAuth2 access token for authorization: MobileApp_Implicit
     */
    public function setMobileApp_Implicit($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    /**
     * Configure OAuth2 access token for authorization: admin_AccessCode
     */
    public function setadmin_AccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    // ...

    /**
     * Implementation of AccessControlApiInterface#getAuthCode
     */
    public function getAuthCode($grant_type, $client_id, $redirect_uri)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grant_type** | **string**| value &#x3D; authorization_code |
 **client_id** | **string**| a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) |
 **redirect_uri** | **string**| App Callback URI |

### Return type

[**Swagger\Server\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode), [MobileApp_Implicit](../../README.md#MobileApp_Implicit), [admin_AccessCode](../../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **getTokenRequest**
> Swagger\Server\Model\OAuthToken getTokenRequest($grant_type, $client_id, $client_secret)



Applications request an implicit token with a client id and secret prior to user authentication

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/AccessControlApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\AccessControlApiInterface;

class AccessControlApi implements AccessControlApiInterface
{

    /**
     * Configure OAuth2 access token for authorization: AccessCode
     */
    public function setAccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    /**
     * Configure OAuth2 access token for authorization: MobileApp_Implicit
     */
    public function setMobileApp_Implicit($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    /**
     * Configure OAuth2 access token for authorization: admin_AccessCode
     */
    public function setadmin_AccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    // ...

    /**
     * Implementation of AccessControlApiInterface#getTokenRequest
     */
    public function getTokenRequest($grant_type, $client_id, $client_secret)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grant_type** | **string**| value &#x3D; implicit |
 **client_id** | **string**| a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) |
 **client_secret** | **string**| the client secret associated to the app client id (this changes with each app store version iteration) |

### Return type

[**Swagger\Server\Model\OAuthToken**](../Model/OAuthToken.md)

### Authorization

[AccessCode](../../README.md#AccessCode), [MobileApp_Implicit](../../README.md#MobileApp_Implicit), [admin_AccessCode](../../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **postTokenRequest**
> Swagger\Server\Model\OAuthToken postTokenRequest()



Authorization Code grant types require a POST to the token endpoint after a GET for Authorization code.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/AccessControlApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\AccessControlApiInterface;

class AccessControlApi implements AccessControlApiInterface
{

    /**
     * Configure OAuth2 access token for authorization: AccessCode
     */
    public function setAccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    /**
     * Configure OAuth2 access token for authorization: MobileApp_Implicit
     */
    public function setMobileApp_Implicit($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    /**
     * Configure OAuth2 access token for authorization: admin_AccessCode
     */
    public function setadmin_AccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    // ...

    /**
     * Implementation of AccessControlApiInterface#postTokenRequest
     */
    public function postTokenRequest()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Swagger\Server\Model\OAuthToken**](../Model/OAuthToken.md)

### Authorization

[AccessCode](../../README.md#AccessCode), [MobileApp_Implicit](../../README.md#MobileApp_Implicit), [admin_AccessCode](../../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

