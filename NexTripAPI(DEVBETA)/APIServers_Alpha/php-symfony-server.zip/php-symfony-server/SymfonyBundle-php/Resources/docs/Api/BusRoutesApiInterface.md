# Swagger\Server\Api\BusRoutesApiInterface

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getDepartures**](BusRoutesApiInterface.md#getDepartures) | **GET** /NexTrip/{STOPID} | 
[**getDirections**](BusRoutesApiInterface.md#getDirections) | **GET** /NexTrip/Directions/{ROUTE} | 
[**getProviders**](BusRoutesApiInterface.md#getProviders) | **GET** /NexTrip/Providers | 
[**getRoutes**](BusRoutesApiInterface.md#getRoutes) | **GET** /NexTrip/Routes | 
[**getStops**](BusRoutesApiInterface.md#getStops) | **GET** /NexTrip/Stops/{ROUTE}/{DIRECTION} | 
[**getTimepointDepartures**](BusRoutesApiInterface.md#getTimepointDepartures) | **GET** /NexTrip/{ROUTE}/{DIRECTION}/{STOP} | 
[**getVehicleLocations**](BusRoutesApiInterface.md#getVehicleLocations) | **GET** /NexTrip/VehicleLocations/{ROUTE} | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.busRoutes:
        class: Acme\MyBundle\Api\BusRoutesApi
        tags:
            - { name: "swagger_server.api", api: "busRoutes" }
    # ...
```

## **getDepartures**
> Swagger\Server\Model\Success getDepartures($stopid)



Returns a list of departures scheduled for any given bus stop.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/BusRoutesApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\BusRoutesApiInterface;

class BusRoutesApi implements BusRoutesApiInterface
{

    /**
     * Configure OAuth2 access token for authorization: AccessCode
     */
    public function setAccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    // ...

    /**
     * Implementation of BusRoutesApiInterface#getDepartures
     */
    public function getDepartures($stopid)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **stopid** | **string**| Specify the value of the Bus Stop ID as an abbreviated string |

### Return type

[**Swagger\Server\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **getDirections**
> Swagger\Server\Model\Success getDirections($route)



Returns the two directions that are valid for a given route.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/BusRoutesApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\BusRoutesApiInterface;

class BusRoutesApi implements BusRoutesApiInterface
{

    /**
     * Configure OAuth2 access token for authorization: AccessCode
     */
    public function setAccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    // ...

    /**
     * Implementation of BusRoutesApiInterface#getDirections
     */
    public function getDirections($route)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. |

### Return type

[**Swagger\Server\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **getProviders**
> Swagger\Server\Model\Success getProviders()



Returns a list of area Transit providers.  Providers are identified in the list of Routes allowing routes to be selected for a single provider.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/BusRoutesApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\BusRoutesApiInterface;

class BusRoutesApi implements BusRoutesApiInterface
{

    /**
     * Configure OAuth2 access token for authorization: AccessCode
     */
    public function setAccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    // ...

    /**
     * Implementation of BusRoutesApiInterface#getProviders
     */
    public function getProviders()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Swagger\Server\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **getRoutes**
> Swagger\Server\Model\RouteData getRoutes()



Returns a list of Transit routes that are in service on the current day.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/BusRoutesApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\BusRoutesApiInterface;

class BusRoutesApi implements BusRoutesApiInterface
{

    /**
     * Configure OAuth2 access token for authorization: AccessCode
     */
    public function setAccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    // ...

    /**
     * Implementation of BusRoutesApiInterface#getRoutes
     */
    public function getRoutes()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Swagger\Server\Model\RouteData**](../Model/RouteData.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **getStops**
> Swagger\Server\Model\Success getStops($route, $direction)



Returns a list of Timepoint stops for the given Route/Direction.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/BusRoutesApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\BusRoutesApiInterface;

class BusRoutesApi implements BusRoutesApiInterface
{

    /**
     * Configure OAuth2 access token for authorization: AccessCode
     */
    public function setAccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    // ...

    /**
     * Implementation of BusRoutesApiInterface#getStops
     */
    public function getStops($route, $direction)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. |
 **direction** | **int**| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) |

### Return type

[**Swagger\Server\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **getTimepointDepartures**
> Swagger\Server\Model\TimePoints getTimepointDepartures($route, $direction, $stop)



Returns the scheduled departures for a selected route, direction and timepoint stop.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/BusRoutesApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\BusRoutesApiInterface;

class BusRoutesApi implements BusRoutesApiInterface
{

    /**
     * Configure OAuth2 access token for authorization: AccessCode
     */
    public function setAccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    // ...

    /**
     * Implementation of BusRoutesApiInterface#getTimepointDepartures
     */
    public function getTimepointDepartures($route, $direction, $stop)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. |
 **direction** | **int**| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) |
 **stop** | **string**| Specify the value of the Bus Stop ID as an abbreviated string |

### Return type

[**Swagger\Server\Model\TimePoints**](../Model/TimePoints.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **getVehicleLocations**
> Swagger\Server\Model\Success getVehicleLocations($route)



This operation returns a list of vehicles currently in service that have recently (within 5 minutes)  reported their locations. A route paramter is used to return results for the given route.  Use \"0\" for the route parameter to return a list of all vehicles in service.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/BusRoutesApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\BusRoutesApiInterface;

class BusRoutesApi implements BusRoutesApiInterface
{

    /**
     * Configure OAuth2 access token for authorization: AccessCode
     */
    public function setAccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    // ...

    /**
     * Implementation of BusRoutesApiInterface#getVehicleLocations
     */
    public function getVehicleLocations($route)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. |

### Return type

[**Swagger\Server\Model\Success**](../Model/Success.md)

### Authorization

[AccessCode](../../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

