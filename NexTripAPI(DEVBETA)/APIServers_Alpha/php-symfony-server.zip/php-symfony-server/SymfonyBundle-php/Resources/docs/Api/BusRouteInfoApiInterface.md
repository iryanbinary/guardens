# Swagger\Server\Api\BusRouteInfoApiInterface

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateroute**](BusRouteInfoApiInterface.md#updateroute) | **POST** /NexTrip/update/{ROUTE} | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.busRouteInfo:
        class: Acme\MyBundle\Api\BusRouteInfoApi
        tags:
            - { name: "swagger_server.api", api: "busRouteInfo" }
    # ...
```

## **updateroute**
> Swagger\Server\Model\RouteData updateroute($route)



Update a bus route

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/BusRouteInfoApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\BusRouteInfoApiInterface;

class BusRouteInfoApi implements BusRouteInfoApiInterface
{

    /**
     * Configure OAuth2 access token for authorization: admin_AccessCode
     */
    public function setadmin_AccessCode($oauthToken)
    {
        // Retrieve logged in user from $oauthToken ...
    }

    // ...

    /**
     * Implementation of BusRouteInfoApiInterface#updateroute
     */
    public function updateroute($route)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. |

### Return type

[**Swagger\Server\Model\RouteData**](../Model/RouteData.md)

### Authorization

[admin_AccessCode](../../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

