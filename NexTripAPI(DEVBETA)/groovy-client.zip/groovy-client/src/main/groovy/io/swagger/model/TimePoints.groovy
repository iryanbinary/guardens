package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class TimePoints {

    Integer code = null

    Boolean actual = null

    Integer blockNumber = null

    String departureText = null

    String departureTime = null

    String description = null

    String gate = null

    Integer route = null

    String routeDirection = null

    String terminal = null

    Integer vehicleHeading = null

    String vehicleLatitude = null

    String vehicleLongitude = null
  

}

