package io.swagger.api;

import groovyx.net.http.*
import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import io.swagger.api.ApiUtils

import io.swagger.model.Err
import io.swagger.model.OAuthToken
import io.swagger.model.Success

import java.util.*;

@Mixin(ApiUtils)
class AccessControlApi {
    String basePath = "https://svc.metrotransit.org"
    String versionPath = "/api/v1"

    def getAuthCode ( String grantType, String clientId, String redirectUri, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/NexTrip/oauth20/authorize"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (grantType == null) {
            throw new RuntimeException("missing required params grantType")
        }
        // verify required params are set
        if (clientId == null) {
            throw new RuntimeException("missing required params clientId")
        }
        // verify required params are set
        if (redirectUri == null) {
            throw new RuntimeException("missing required params redirectUri")
        }

        if (!"null".equals(String.valueOf(grantType)))
            queryParams.put("grant_type", String.valueOf(grantType))
if (!"null".equals(String.valueOf(clientId)))
            queryParams.put("client_id", String.valueOf(clientId))
if (!"null".equals(String.valueOf(redirectUri)))
            queryParams.put("redirect_uri", String.valueOf(redirectUri))


        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Success.class )
                    
    }
    def getTokenRequest ( String grantType, String clientId, String clientSecret, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/NexTrip/oauth20/token"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (grantType == null) {
            throw new RuntimeException("missing required params grantType")
        }
        // verify required params are set
        if (clientId == null) {
            throw new RuntimeException("missing required params clientId")
        }
        // verify required params are set
        if (clientSecret == null) {
            throw new RuntimeException("missing required params clientSecret")
        }

        if (!"null".equals(String.valueOf(grantType)))
            queryParams.put("grant_type", String.valueOf(grantType))
if (!"null".equals(String.valueOf(clientId)))
            queryParams.put("client_id", String.valueOf(clientId))
if (!"null".equals(String.valueOf(clientSecret)))
            queryParams.put("client_secret", String.valueOf(clientSecret))


        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    OAuthToken.class )
                    
    }
    def postTokenRequest ( Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/NexTrip/oauth20/token"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "POST", "",
                    OAuthToken.class )
                    
    }
}
