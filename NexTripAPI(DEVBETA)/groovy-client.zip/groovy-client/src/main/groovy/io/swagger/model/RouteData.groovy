package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class RouteData {

    Integer code = null

    Integer route = null

    Integer providerID = null

    String description = null
  

}

