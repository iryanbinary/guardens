package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class OAuthToken {

    String token = null

    String refreshToken = null

    String tokenType = null

    String expiresIn = null

    String scopes = null
  

}

