package io.swagger.api;

import groovyx.net.http.*
import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import io.swagger.api.ApiUtils

import io.swagger.model.Err
import io.swagger.model.RouteData
import io.swagger.model.Success
import io.swagger.model.TimePoints

import java.util.*;

@Mixin(ApiUtils)
class BusRoutesApi {
    String basePath = "https://svc.metrotransit.org"
    String versionPath = "/api/v1"

    def getDepartures ( String STOPID, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/NexTrip/{STOPID}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (STOPID == null) {
            throw new RuntimeException("missing required params STOPID")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Success.class )
                    
    }
    def getDirections ( Integer ROUTE, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/NexTrip/Directions/{ROUTE}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (ROUTE == null) {
            throw new RuntimeException("missing required params ROUTE")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Success.class )
                    
    }
    def getProviders ( Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/NexTrip/Providers"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Success.class )
                    
    }
    def getRoutes ( Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/NexTrip/Routes"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    RouteData.class )
                    
    }
    def getStops ( Integer ROUTE, Integer DIRECTION, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/NexTrip/Stops/{ROUTE}/{DIRECTION}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (ROUTE == null) {
            throw new RuntimeException("missing required params ROUTE")
        }
        // verify required params are set
        if (DIRECTION == null) {
            throw new RuntimeException("missing required params DIRECTION")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Success.class )
                    
    }
    def getTimepointDepartures ( Integer ROUTE, Integer DIRECTION, String STOP, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/NexTrip/{ROUTE}/{DIRECTION}/{STOP}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (ROUTE == null) {
            throw new RuntimeException("missing required params ROUTE")
        }
        // verify required params are set
        if (DIRECTION == null) {
            throw new RuntimeException("missing required params DIRECTION")
        }
        // verify required params are set
        if (STOP == null) {
            throw new RuntimeException("missing required params STOP")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    TimePoints.class )
                    
    }
    def getVehicleLocations ( Integer ROUTE, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/NexTrip/VehicleLocations/{ROUTE}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (ROUTE == null) {
            throw new RuntimeException("missing required params ROUTE")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Success.class )
                    
    }
}
