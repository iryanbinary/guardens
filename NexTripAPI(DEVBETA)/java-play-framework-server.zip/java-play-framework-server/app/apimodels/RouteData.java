package apimodels;

import java.util.Objects;
import javax.validation.constraints.*;
import com.fasterxml.jackson.annotation.*;
/**
 * RouteData
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2017-10-23T19:48:00.059Z")

public class RouteData   {
  @JsonProperty("code")
  private Integer code = null;

  @JsonProperty("Route")
  private Integer route = null;

  @JsonProperty("ProviderID")
  private Integer providerID = null;

  @JsonProperty("Description")
  private String description = null;

  public RouteData code(Integer code) {
    this.code = code;
    return this;
  }

   /**
   * Get code
   * @return code
  **/
    public Integer getCode() {
    return code;
  }

  public void setCode(Integer code) {
    this.code = code;
  }

  public RouteData route(Integer route) {
    this.route = route;
    return this;
  }

   /**
   * Get route
   * @return route
  **/
    public Integer getRoute() {
    return route;
  }

  public void setRoute(Integer route) {
    this.route = route;
  }

  public RouteData providerID(Integer providerID) {
    this.providerID = providerID;
    return this;
  }

   /**
   * Get providerID
   * @return providerID
  **/
    public Integer getProviderID() {
    return providerID;
  }

  public void setProviderID(Integer providerID) {
    this.providerID = providerID;
  }

  public RouteData description(String description) {
    this.description = description;
    return this;
  }

   /**
   * Get description
   * @return description
  **/
    public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RouteData routeData = (RouteData) o;
    return Objects.equals(this.code, routeData.code) &&
        Objects.equals(this.route, routeData.route) &&
        Objects.equals(this.providerID, routeData.providerID) &&
        Objects.equals(this.description, routeData.description);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, route, providerID, description);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RouteData {\n");
    
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    route: ").append(toIndentedString(route)).append("\n");
    sb.append("    providerID: ").append(toIndentedString(providerID)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

