package apimodels;

import java.util.Objects;
import javax.validation.constraints.*;
import com.fasterxml.jackson.annotation.*;
/**
 * TimePoints
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2017-10-23T19:48:00.059Z")

public class TimePoints   {
  @JsonProperty("code")
  private Integer code = null;

  @JsonProperty("Actual")
  private Boolean actual = null;

  @JsonProperty("BlockNumber")
  private Integer blockNumber = null;

  @JsonProperty("DepartureText")
  private String departureText = null;

  @JsonProperty("DepartureTime")
  private String departureTime = null;

  @JsonProperty("Description")
  private String description = null;

  @JsonProperty("Gate")
  private String gate = null;

  @JsonProperty("Route")
  private Integer route = null;

  @JsonProperty("RouteDirection")
  private String routeDirection = null;

  @JsonProperty("Terminal")
  private String terminal = null;

  @JsonProperty("VehicleHeading")
  private Integer vehicleHeading = null;

  @JsonProperty("VehicleLatitude")
  private String vehicleLatitude = null;

  @JsonProperty("VehicleLongitude")
  private String vehicleLongitude = null;

  public TimePoints code(Integer code) {
    this.code = code;
    return this;
  }

   /**
   * Get code
   * @return code
  **/
    public Integer getCode() {
    return code;
  }

  public void setCode(Integer code) {
    this.code = code;
  }

  public TimePoints actual(Boolean actual) {
    this.actual = actual;
    return this;
  }

   /**
   * Get actual
   * @return actual
  **/
    public Boolean getActual() {
    return actual;
  }

  public void setActual(Boolean actual) {
    this.actual = actual;
  }

  public TimePoints blockNumber(Integer blockNumber) {
    this.blockNumber = blockNumber;
    return this;
  }

   /**
   * Get blockNumber
   * @return blockNumber
  **/
    public Integer getBlockNumber() {
    return blockNumber;
  }

  public void setBlockNumber(Integer blockNumber) {
    this.blockNumber = blockNumber;
  }

  public TimePoints departureText(String departureText) {
    this.departureText = departureText;
    return this;
  }

   /**
   * Get departureText
   * @return departureText
  **/
    public String getDepartureText() {
    return departureText;
  }

  public void setDepartureText(String departureText) {
    this.departureText = departureText;
  }

  public TimePoints departureTime(String departureTime) {
    this.departureTime = departureTime;
    return this;
  }

   /**
   * Get departureTime
   * @return departureTime
  **/
    public String getDepartureTime() {
    return departureTime;
  }

  public void setDepartureTime(String departureTime) {
    this.departureTime = departureTime;
  }

  public TimePoints description(String description) {
    this.description = description;
    return this;
  }

   /**
   * Get description
   * @return description
  **/
    public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public TimePoints gate(String gate) {
    this.gate = gate;
    return this;
  }

   /**
   * Get gate
   * @return gate
  **/
    public String getGate() {
    return gate;
  }

  public void setGate(String gate) {
    this.gate = gate;
  }

  public TimePoints route(Integer route) {
    this.route = route;
    return this;
  }

   /**
   * Get route
   * @return route
  **/
    public Integer getRoute() {
    return route;
  }

  public void setRoute(Integer route) {
    this.route = route;
  }

  public TimePoints routeDirection(String routeDirection) {
    this.routeDirection = routeDirection;
    return this;
  }

   /**
   * Get routeDirection
   * @return routeDirection
  **/
    public String getRouteDirection() {
    return routeDirection;
  }

  public void setRouteDirection(String routeDirection) {
    this.routeDirection = routeDirection;
  }

  public TimePoints terminal(String terminal) {
    this.terminal = terminal;
    return this;
  }

   /**
   * Get terminal
   * @return terminal
  **/
    public String getTerminal() {
    return terminal;
  }

  public void setTerminal(String terminal) {
    this.terminal = terminal;
  }

  public TimePoints vehicleHeading(Integer vehicleHeading) {
    this.vehicleHeading = vehicleHeading;
    return this;
  }

   /**
   * Get vehicleHeading
   * @return vehicleHeading
  **/
    public Integer getVehicleHeading() {
    return vehicleHeading;
  }

  public void setVehicleHeading(Integer vehicleHeading) {
    this.vehicleHeading = vehicleHeading;
  }

  public TimePoints vehicleLatitude(String vehicleLatitude) {
    this.vehicleLatitude = vehicleLatitude;
    return this;
  }

   /**
   * Get vehicleLatitude
   * @return vehicleLatitude
  **/
    public String getVehicleLatitude() {
    return vehicleLatitude;
  }

  public void setVehicleLatitude(String vehicleLatitude) {
    this.vehicleLatitude = vehicleLatitude;
  }

  public TimePoints vehicleLongitude(String vehicleLongitude) {
    this.vehicleLongitude = vehicleLongitude;
    return this;
  }

   /**
   * Get vehicleLongitude
   * @return vehicleLongitude
  **/
    public String getVehicleLongitude() {
    return vehicleLongitude;
  }

  public void setVehicleLongitude(String vehicleLongitude) {
    this.vehicleLongitude = vehicleLongitude;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TimePoints timePoints = (TimePoints) o;
    return Objects.equals(this.code, timePoints.code) &&
        Objects.equals(this.actual, timePoints.actual) &&
        Objects.equals(this.blockNumber, timePoints.blockNumber) &&
        Objects.equals(this.departureText, timePoints.departureText) &&
        Objects.equals(this.departureTime, timePoints.departureTime) &&
        Objects.equals(this.description, timePoints.description) &&
        Objects.equals(this.gate, timePoints.gate) &&
        Objects.equals(this.route, timePoints.route) &&
        Objects.equals(this.routeDirection, timePoints.routeDirection) &&
        Objects.equals(this.terminal, timePoints.terminal) &&
        Objects.equals(this.vehicleHeading, timePoints.vehicleHeading) &&
        Objects.equals(this.vehicleLatitude, timePoints.vehicleLatitude) &&
        Objects.equals(this.vehicleLongitude, timePoints.vehicleLongitude);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, actual, blockNumber, departureText, departureTime, description, gate, route, routeDirection, terminal, vehicleHeading, vehicleLatitude, vehicleLongitude);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TimePoints {\n");
    
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    actual: ").append(toIndentedString(actual)).append("\n");
    sb.append("    blockNumber: ").append(toIndentedString(blockNumber)).append("\n");
    sb.append("    departureText: ").append(toIndentedString(departureText)).append("\n");
    sb.append("    departureTime: ").append(toIndentedString(departureTime)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    gate: ").append(toIndentedString(gate)).append("\n");
    sb.append("    route: ").append(toIndentedString(route)).append("\n");
    sb.append("    routeDirection: ").append(toIndentedString(routeDirection)).append("\n");
    sb.append("    terminal: ").append(toIndentedString(terminal)).append("\n");
    sb.append("    vehicleHeading: ").append(toIndentedString(vehicleHeading)).append("\n");
    sb.append("    vehicleLatitude: ").append(toIndentedString(vehicleLatitude)).append("\n");
    sb.append("    vehicleLongitude: ").append(toIndentedString(vehicleLongitude)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

