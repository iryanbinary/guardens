package controllers;

import apimodels.Err;
import apimodels.OAuthToken;
import apimodels.Success;

import play.mvc.Controller;
import play.mvc.Result;
import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.inject.Inject;
import java.io.IOException;
import swagger.SwaggerUtils;
import com.fasterxml.jackson.core.type.TypeReference;

import javax.validation.constraints.*;

import swagger.SwaggerUtils.ApiAction;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2017-10-23T19:48:00.059Z")

public class AccessControlApiController extends Controller {

    private final AccessControlApiControllerImp imp;
    private final ObjectMapper mapper;

    @Inject
    private AccessControlApiController(AccessControlApiControllerImp imp) {
        this.imp = imp;
        mapper = new ObjectMapper();
    }


    @ApiAction
    public Result getAuthCode() throws Exception {
        String valuegrantType = request().getQueryString("grantType");
        String grantType;

        grantType = (String)valuegrantType;

        String valueclientId = request().getQueryString("clientId");
        String clientId;

        clientId = (String)valueclientId;

        String valueredirectUri = request().getQueryString("redirectUri");
        String redirectUri;

        redirectUri = (String)valueredirectUri;

        Success obj = imp.getAuthCode(grantType, clientId, redirectUri);
        JsonNode result = mapper.valueToTree(obj);
        return ok(result);
        
    }

    @ApiAction
    public Result getTokenRequest() throws Exception {
        String valuegrantType = request().getQueryString("grantType");
        String grantType;

        grantType = (String)valuegrantType;

        String valueclientId = request().getQueryString("clientId");
        String clientId;

        clientId = (String)valueclientId;

        String valueclientSecret = request().getQueryString("clientSecret");
        String clientSecret;

        clientSecret = (String)valueclientSecret;

        OAuthToken obj = imp.getTokenRequest(grantType, clientId, clientSecret);
        JsonNode result = mapper.valueToTree(obj);
        return ok(result);
        
    }

    @ApiAction
    public Result postTokenRequest() throws Exception {
        OAuthToken obj = imp.postTokenRequest();
        JsonNode result = mapper.valueToTree(obj);
        return ok(result);
        
    }
}
