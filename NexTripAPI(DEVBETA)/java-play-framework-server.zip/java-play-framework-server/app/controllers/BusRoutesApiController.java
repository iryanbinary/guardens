package controllers;

import apimodels.Err;
import apimodels.RouteData;
import apimodels.Success;
import apimodels.TimePoints;

import play.mvc.Controller;
import play.mvc.Result;
import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.inject.Inject;
import java.io.IOException;
import swagger.SwaggerUtils;
import com.fasterxml.jackson.core.type.TypeReference;

import javax.validation.constraints.*;

import swagger.SwaggerUtils.ApiAction;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2017-10-23T19:48:00.059Z")

public class BusRoutesApiController extends Controller {

    private final BusRoutesApiControllerImp imp;
    private final ObjectMapper mapper;

    @Inject
    private BusRoutesApiController(BusRoutesApiControllerImp imp) {
        this.imp = imp;
        mapper = new ObjectMapper();
    }


    @ApiAction
    public Result getDepartures(String STOPID) throws Exception {
        Success obj = imp.getDepartures(STOPID);
        JsonNode result = mapper.valueToTree(obj);
        return ok(result);
        
    }

    @ApiAction
    public Result getDirections(Integer ROUTE) throws Exception {
        Success obj = imp.getDirections(ROUTE);
        JsonNode result = mapper.valueToTree(obj);
        return ok(result);
        
    }

    @ApiAction
    public Result getProviders() throws Exception {
        Success obj = imp.getProviders();
        JsonNode result = mapper.valueToTree(obj);
        return ok(result);
        
    }

    @ApiAction
    public Result getRoutes() throws Exception {
        RouteData obj = imp.getRoutes();
        JsonNode result = mapper.valueToTree(obj);
        return ok(result);
        
    }

    @ApiAction
    public Result getStops(Integer ROUTE,Integer DIRECTION) throws Exception {
        Success obj = imp.getStops(ROUTE, DIRECTION);
        JsonNode result = mapper.valueToTree(obj);
        return ok(result);
        
    }

    @ApiAction
    public Result getTimepointDepartures(Integer ROUTE,Integer DIRECTION,String STOP) throws Exception {
        TimePoints obj = imp.getTimepointDepartures(ROUTE, DIRECTION, STOP);
        JsonNode result = mapper.valueToTree(obj);
        return ok(result);
        
    }

    @ApiAction
    public Result getVehicleLocations(Integer ROUTE) throws Exception {
        Success obj = imp.getVehicleLocations(ROUTE);
        JsonNode result = mapper.valueToTree(obj);
        return ok(result);
        
    }
}
