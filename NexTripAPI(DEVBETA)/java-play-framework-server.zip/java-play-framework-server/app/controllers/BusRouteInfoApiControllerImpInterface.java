package controllers;

import apimodels.Err;
import apimodels.RouteData;

import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

import javax.validation.constraints.*;

public interface BusRouteInfoApiControllerImpInterface {
    RouteData updateroute(Integer ROUTE) throws Exception;

}
