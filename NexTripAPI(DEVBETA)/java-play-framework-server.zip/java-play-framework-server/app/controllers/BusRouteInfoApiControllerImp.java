package controllers;

import apimodels.Err;
import apimodels.RouteData;

import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.FileInputStream;
import javax.validation.constraints.*;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2017-10-23T19:48:00.059Z")

public class BusRouteInfoApiControllerImp implements BusRouteInfoApiControllerImpInterface {
    @Override
    public RouteData updateroute(Integer ROUTE) throws Exception {
        //Do your magic!!!
        return new RouteData();
    }

}
