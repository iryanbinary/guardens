package controllers;

import apimodels.Err;
import apimodels.OAuthToken;
import apimodels.Success;

import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.FileInputStream;
import javax.validation.constraints.*;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2017-10-23T19:48:00.059Z")

public class AccessControlApiControllerImp implements AccessControlApiControllerImpInterface {
    @Override
    public Success getAuthCode( @NotNull String grantType,  @NotNull String clientId,  @NotNull String redirectUri) throws Exception {
        //Do your magic!!!
        return new Success();
    }

    @Override
    public OAuthToken getTokenRequest( @NotNull String grantType,  @NotNull String clientId,  @NotNull String clientSecret) throws Exception {
        //Do your magic!!!
        return new OAuthToken();
    }

    @Override
    public OAuthToken postTokenRequest() throws Exception {
        //Do your magic!!!
        return new OAuthToken();
    }

}
