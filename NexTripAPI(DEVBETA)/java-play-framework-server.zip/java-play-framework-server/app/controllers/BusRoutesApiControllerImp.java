package controllers;

import apimodels.Err;
import apimodels.RouteData;
import apimodels.Success;
import apimodels.TimePoints;

import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.FileInputStream;
import javax.validation.constraints.*;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2017-10-23T19:48:00.059Z")

public class BusRoutesApiControllerImp implements BusRoutesApiControllerImpInterface {
    @Override
    public Success getDepartures(String STOPID) throws Exception {
        //Do your magic!!!
        return new Success();
    }

    @Override
    public Success getDirections(Integer ROUTE) throws Exception {
        //Do your magic!!!
        return new Success();
    }

    @Override
    public Success getProviders() throws Exception {
        //Do your magic!!!
        return new Success();
    }

    @Override
    public RouteData getRoutes() throws Exception {
        //Do your magic!!!
        return new RouteData();
    }

    @Override
    public Success getStops(Integer ROUTE, Integer DIRECTION) throws Exception {
        //Do your magic!!!
        return new Success();
    }

    @Override
    public TimePoints getTimepointDepartures(Integer ROUTE, Integer DIRECTION, String STOP) throws Exception {
        //Do your magic!!!
        return new TimePoints();
    }

    @Override
    public Success getVehicleLocations(Integer ROUTE) throws Exception {
        //Do your magic!!!
        return new Success();
    }

}
