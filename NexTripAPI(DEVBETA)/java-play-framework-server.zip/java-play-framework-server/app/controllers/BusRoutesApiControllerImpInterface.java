package controllers;

import apimodels.Err;
import apimodels.RouteData;
import apimodels.Success;
import apimodels.TimePoints;

import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

import javax.validation.constraints.*;

public interface BusRoutesApiControllerImpInterface {
    Success getDepartures(String STOPID) throws Exception;

    Success getDirections(Integer ROUTE) throws Exception;

    Success getProviders() throws Exception;

    RouteData getRoutes() throws Exception;

    Success getStops(Integer ROUTE, Integer DIRECTION) throws Exception;

    TimePoints getTimepointDepartures(Integer ROUTE, Integer DIRECTION, String STOP) throws Exception;

    Success getVehicleLocations(Integer ROUTE) throws Exception;

}
