package controllers;

import apimodels.Err;
import apimodels.OAuthToken;
import apimodels.Success;

import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

import javax.validation.constraints.*;

public interface AccessControlApiControllerImpInterface {
    Success getAuthCode( @NotNull String grantType,  @NotNull String clientId,  @NotNull String redirectUri) throws Exception;

    OAuthToken getTokenRequest( @NotNull String grantType,  @NotNull String clientId,  @NotNull String clientSecret) throws Exception;

    OAuthToken postTokenRequest() throws Exception;

}
