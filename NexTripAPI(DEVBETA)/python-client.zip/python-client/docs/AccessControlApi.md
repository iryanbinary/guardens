# swagger_client.AccessControlApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_auth_code**](AccessControlApi.md#get_auth_code) | **GET** /NexTrip/oauth20/authorize | 
[**get_token_request**](AccessControlApi.md#get_token_request) | **GET** /NexTrip/oauth20/token | 
[**post_token_request**](AccessControlApi.md#post_token_request) | **POST** /NexTrip/oauth20/token | 


# **get_auth_code**
> Success get_auth_code(grant_type, client_id, redirect_uri)



Request a temporary code for the desired API Access Token Scope(s)

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'
# Configure OAuth2 access token for authorization: MobileApp_Implicit
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'
# Configure OAuth2 access token for authorization: admin_AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.AccessControlApi()
grant_type = 'grant_type_example' # str | value = authorization_code
client_id = 'client_id_example' # str | a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
redirect_uri = 'redirect_uri_example' # str | App Callback URI

try: 
    api_response = api_instance.get_auth_code(grant_type, client_id, redirect_uri)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccessControlApi->get_auth_code: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grant_type** | **str**| value &#x3D; authorization_code | 
 **client_id** | **str**| a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) | 
 **redirect_uri** | **str**| App Callback URI | 

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_request**
> OAuthToken get_token_request(grant_type, client_id, client_secret)



Applications request an implicit token with a client id and secret prior to user authentication

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'
# Configure OAuth2 access token for authorization: MobileApp_Implicit
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'
# Configure OAuth2 access token for authorization: admin_AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.AccessControlApi()
grant_type = 'grant_type_example' # str | value = implicit
client_id = 'client_id_example' # str | a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
client_secret = 'client_secret_example' # str | the client secret associated to the app client id (this changes with each app store version iteration)

try: 
    api_response = api_instance.get_token_request(grant_type, client_id, client_secret)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccessControlApi->get_token_request: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grant_type** | **str**| value &#x3D; implicit | 
 **client_id** | **str**| a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) | 
 **client_secret** | **str**| the client secret associated to the app client id (this changes with each app store version iteration) | 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_token_request**
> OAuthToken post_token_request()



Authorization Code grant types require a POST to the token endpoint after a GET for Authorization code.

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'
# Configure OAuth2 access token for authorization: MobileApp_Implicit
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'
# Configure OAuth2 access token for authorization: admin_AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.AccessControlApi()

try: 
    api_response = api_instance.post_token_request()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccessControlApi->post_token_request: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

