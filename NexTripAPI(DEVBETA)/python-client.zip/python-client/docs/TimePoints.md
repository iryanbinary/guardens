# TimePoints

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **int** |  | [optional] 
**actual** | **bool** |  | [optional] 
**block_number** | **int** |  | [optional] 
**departure_text** | **str** |  | [optional] 
**departure_time** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**gate** | **str** |  | [optional] 
**route** | **int** |  | [optional] 
**route_direction** | **str** |  | [optional] 
**terminal** | **str** |  | [optional] 
**vehicle_heading** | **int** |  | [optional] 
**vehicle_latitude** | **str** |  | [optional] 
**vehicle_longitude** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


