# swagger_client.BusRouteInfoApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateroute**](BusRouteInfoApi.md#updateroute) | **POST** /NexTrip/update/{ROUTE} | 


# **updateroute**
> RouteData updateroute(route)



Update a bus route

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: admin_AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BusRouteInfoApi()
route = 56 # int | Sepcify the Route ID as an integer.

try: 
    api_response = api_instance.updateroute(route)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BusRouteInfoApi->updateroute: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. | 

### Return type

[**RouteData**](RouteData.md)

### Authorization

[admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

