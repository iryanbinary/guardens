# swagger_client.BusRoutesApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_departures**](BusRoutesApi.md#get_departures) | **GET** /NexTrip/{STOPID} | 
[**get_directions**](BusRoutesApi.md#get_directions) | **GET** /NexTrip/Directions/{ROUTE} | 
[**get_providers**](BusRoutesApi.md#get_providers) | **GET** /NexTrip/Providers | 
[**get_routes**](BusRoutesApi.md#get_routes) | **GET** /NexTrip/Routes | 
[**get_stops**](BusRoutesApi.md#get_stops) | **GET** /NexTrip/Stops/{ROUTE}/{DIRECTION} | 
[**get_timepoint_departures**](BusRoutesApi.md#get_timepoint_departures) | **GET** /NexTrip/{ROUTE}/{DIRECTION}/{STOP} | 
[**get_vehicle_locations**](BusRoutesApi.md#get_vehicle_locations) | **GET** /NexTrip/VehicleLocations/{ROUTE} | 


# **get_departures**
> Success get_departures(stopid)



Returns a list of departures scheduled for any given bus stop.

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BusRoutesApi()
stopid = 'stopid_example' # str | Specify the value of the Bus Stop ID as an abbreviated string

try: 
    api_response = api_instance.get_departures(stopid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BusRoutesApi->get_departures: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **stopid** | **str**| Specify the value of the Bus Stop ID as an abbreviated string | 

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_directions**
> Success get_directions(route)



Returns the two directions that are valid for a given route.

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BusRoutesApi()
route = 56 # int | Sepcify the Route ID as an integer.

try: 
    api_response = api_instance.get_directions(route)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BusRoutesApi->get_directions: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. | 

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_providers**
> Success get_providers()



Returns a list of area Transit providers.  Providers are identified in the list of Routes allowing routes to be selected for a single provider. 

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BusRoutesApi()

try: 
    api_response = api_instance.get_providers()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BusRoutesApi->get_providers: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_routes**
> RouteData get_routes()



Returns a list of Transit routes that are in service on the current day.

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BusRoutesApi()

try: 
    api_response = api_instance.get_routes()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BusRoutesApi->get_routes: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**RouteData**](RouteData.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_stops**
> Success get_stops(route, direction)



Returns a list of Timepoint stops for the given Route/Direction.

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BusRoutesApi()
route = 56 # int | Sepcify the Route ID as an integer.
direction = 56 # int | Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)

try: 
    api_response = api_instance.get_stops(route, direction)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BusRoutesApi->get_stops: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. | 
 **direction** | **int**| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) | 

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_timepoint_departures**
> TimePoints get_timepoint_departures(route, direction, stop)



Returns the scheduled departures for a selected route, direction and timepoint stop.

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BusRoutesApi()
route = 56 # int | Sepcify the Route ID as an integer.
direction = 56 # int | Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)
stop = 'stop_example' # str | Specify the value of the Bus Stop ID as an abbreviated string

try: 
    api_response = api_instance.get_timepoint_departures(route, direction, stop)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BusRoutesApi->get_timepoint_departures: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. | 
 **direction** | **int**| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) | 
 **stop** | **str**| Specify the value of the Bus Stop ID as an abbreviated string | 

### Return type

[**TimePoints**](TimePoints.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_vehicle_locations**
> Success get_vehicle_locations(route)



This operation returns a list of vehicles currently in service that have recently (within 5 minutes)  reported their locations. A route paramter is used to return results for the given route.  Use \"0\" for the route parameter to return a list of all vehicles in service.

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BusRoutesApi()
route = 56 # int | Sepcify the Route ID as an integer.

try: 
    api_response = api_instance.get_vehicle_locations(route)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BusRoutesApi->get_vehicle_locations: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **route** | **int**| Sepcify the Route ID as an integer. | 

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

