# OAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **str** |  | [optional] 
**refresh_token** | **str** |  | [optional] 
**token_type** | **str** |  | [optional] 
**expires_in** | **str** |  | [optional] 
**scopes** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


