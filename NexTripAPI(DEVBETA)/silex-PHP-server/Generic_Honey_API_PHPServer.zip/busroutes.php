<?php
require_once __DIR__ . '/vendor/autoload.php';

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Silex\Application;

$app = new Silex\Application();


$app->GET('/oauth20/authorize', function(Application $app, Request $request) {
            $grant_type = $request->get('grant_type');
            $client_id = $request->get('client_id');
            $redirect_uri = $request->get('redirect_uri');
            return new Response('Bearer TODOINTEGRATEWITHOAUTHSERVER');
            });


$app->GET('/oauth20/token', function(Application $app, Request $request) {
            $grant_type = $request->get('grant_type');
            $client_id = $request->get('client_id');
            $client_secret = $request->get('client_secret');
            return new Response('Bearer TODOINTEGRATEWITHOAUTHSERVER');
            });


$app->POST('/oauth20/token', function(Application $app, Request $request) {
            return new Response('TODO implement an OAuth token POST request handler');
            });


$app->POST('/v1/routes', function(Application $app, Request $request) {
            return new Response('TODO implement JSON message POST message handler');
            });


$app->GET('/v1/routes', function(Application $app, Request $request) {
            $expressonly = $request->get('expressonly');
            $limit = $request->get('limit');
            $search = $request->get('search');
            return new Response('{"message":"The route from origin to destination is an express route with 10 stops and a duration of 20 minutes."}');
            });


$app->run();
