# IO.Swagger.Model.OAuthToken
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Token** | **string** |  | [optional] 
**RefreshToken** | **string** |  | [optional] 
**TokenType** | **string** |  | [optional] 
**ExpiresIn** | **string** |  | [optional] 
**Scopes** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

