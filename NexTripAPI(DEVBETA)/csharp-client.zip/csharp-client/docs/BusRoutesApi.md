# IO.Swagger.Api.BusRoutesApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetDepartures**](BusRoutesApi.md#getdepartures) | **GET** /NexTrip/{STOPID} | 
[**GetDirections**](BusRoutesApi.md#getdirections) | **GET** /NexTrip/Directions/{ROUTE} | 
[**GetProviders**](BusRoutesApi.md#getproviders) | **GET** /NexTrip/Providers | 
[**GetRoutes**](BusRoutesApi.md#getroutes) | **GET** /NexTrip/Routes | 
[**GetStops**](BusRoutesApi.md#getstops) | **GET** /NexTrip/Stops/{ROUTE}/{DIRECTION} | 
[**GetTimepointDepartures**](BusRoutesApi.md#gettimepointdepartures) | **GET** /NexTrip/{ROUTE}/{DIRECTION}/{STOP} | 
[**GetVehicleLocations**](BusRoutesApi.md#getvehiclelocations) | **GET** /NexTrip/VehicleLocations/{ROUTE} | 


<a name="getdepartures"></a>
# **GetDepartures**
> Success GetDepartures (string STOPID)



Returns a list of departures scheduled for any given bus stop.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDeparturesExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BusRoutesApi();
            var STOPID = STOPID_example;  // string | Specify the value of the Bus Stop ID as an abbreviated string

            try
            {
                Success result = apiInstance.GetDepartures(STOPID);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BusRoutesApi.GetDepartures: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **STOPID** | **string**| Specify the value of the Bus Stop ID as an abbreviated string | 

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdirections"></a>
# **GetDirections**
> Success GetDirections (int? ROUTE)



Returns the two directions that are valid for a given route.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDirectionsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BusRoutesApi();
            var ROUTE = 56;  // int? | Sepcify the Route ID as an integer.

            try
            {
                Success result = apiInstance.GetDirections(ROUTE);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BusRoutesApi.GetDirections: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ROUTE** | **int?**| Sepcify the Route ID as an integer. | 

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getproviders"></a>
# **GetProviders**
> Success GetProviders ()



Returns a list of area Transit providers.  Providers are identified in the list of Routes allowing routes to be selected for a single provider. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetProvidersExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BusRoutesApi();

            try
            {
                Success result = apiInstance.GetProviders();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BusRoutesApi.GetProviders: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getroutes"></a>
# **GetRoutes**
> RouteData GetRoutes ()



Returns a list of Transit routes that are in service on the current day.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetRoutesExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BusRoutesApi();

            try
            {
                RouteData result = apiInstance.GetRoutes();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BusRoutesApi.GetRoutes: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**RouteData**](RouteData.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getstops"></a>
# **GetStops**
> Success GetStops (int? ROUTE, int? DIRECTION)



Returns a list of Timepoint stops for the given Route/Direction.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetStopsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BusRoutesApi();
            var ROUTE = 56;  // int? | Sepcify the Route ID as an integer.
            var DIRECTION = 56;  // int? | Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)

            try
            {
                Success result = apiInstance.GetStops(ROUTE, DIRECTION);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BusRoutesApi.GetStops: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ROUTE** | **int?**| Sepcify the Route ID as an integer. | 
 **DIRECTION** | **int?**| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) | 

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettimepointdepartures"></a>
# **GetTimepointDepartures**
> TimePoints GetTimepointDepartures (int? ROUTE, int? DIRECTION, string STOP)



Returns the scheduled departures for a selected route, direction and timepoint stop.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTimepointDeparturesExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BusRoutesApi();
            var ROUTE = 56;  // int? | Sepcify the Route ID as an integer.
            var DIRECTION = 56;  // int? | Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North)
            var STOP = STOP_example;  // string | Specify the value of the Bus Stop ID as an abbreviated string

            try
            {
                TimePoints result = apiInstance.GetTimepointDepartures(ROUTE, DIRECTION, STOP);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BusRoutesApi.GetTimepointDepartures: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ROUTE** | **int?**| Sepcify the Route ID as an integer. | 
 **DIRECTION** | **int?**| Specify the direction as an integer.  1 (South), 2 (East), 3 (West), 4 (North) | 
 **STOP** | **string**| Specify the value of the Bus Stop ID as an abbreviated string | 

### Return type

[**TimePoints**](TimePoints.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getvehiclelocations"></a>
# **GetVehicleLocations**
> Success GetVehicleLocations (int? ROUTE)



This operation returns a list of vehicles currently in service that have recently (within 5 minutes)  reported their locations. A route paramter is used to return results for the given route.  Use \"0\" for the route parameter to return a list of all vehicles in service.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetVehicleLocationsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BusRoutesApi();
            var ROUTE = 56;  // int? | Sepcify the Route ID as an integer.

            try
            {
                Success result = apiInstance.GetVehicleLocations(ROUTE);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BusRoutesApi.GetVehicleLocations: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ROUTE** | **int?**| Sepcify the Route ID as an integer. | 

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

