# IO.Swagger.Api.AccessControlApi

All URIs are relative to *https://svc.metrotransit.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAuthCode**](AccessControlApi.md#getauthcode) | **GET** /NexTrip/oauth20/authorize | 
[**GetTokenRequest**](AccessControlApi.md#gettokenrequest) | **GET** /NexTrip/oauth20/token | 
[**PostTokenRequest**](AccessControlApi.md#posttokenrequest) | **POST** /NexTrip/oauth20/token | 


<a name="getauthcode"></a>
# **GetAuthCode**
> Success GetAuthCode (string grantType, string clientId, string redirectUri)



Request a temporary code for the desired API Access Token Scope(s)

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAuthCodeExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";
            // Configure OAuth2 access token for authorization: MobileApp_Implicit
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";
            // Configure OAuth2 access token for authorization: admin_AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new AccessControlApi();
            var grantType = grantType_example;  // string | value = authorization_code
            var clientId = clientId_example;  // string | a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
            var redirectUri = redirectUri_example;  // string | App Callback URI

            try
            {
                Success result = apiInstance.GetAuthCode(grantType, clientId, redirectUri);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AccessControlApi.GetAuthCode: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grantType** | **string**| value &#x3D; authorization_code | 
 **clientId** | **string**| a valid OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) | 
 **redirectUri** | **string**| App Callback URI | 

### Return type

[**Success**](Success.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettokenrequest"></a>
# **GetTokenRequest**
> OAuthToken GetTokenRequest (string grantType, string clientId, string clientSecret)



Applications request an implicit token with a client id and secret prior to user authentication

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTokenRequestExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";
            // Configure OAuth2 access token for authorization: MobileApp_Implicit
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";
            // Configure OAuth2 access token for authorization: admin_AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new AccessControlApi();
            var grantType = grantType_example;  // string | value = implicit
            var clientId = clientId_example;  // string | a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration)
            var clientSecret = clientSecret_example;  // string | the client secret associated to the app client id (this changes with each app store version iteration)

            try
            {
                OAuthToken result = apiInstance.GetTokenRequest(grantType, clientId, clientSecret);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AccessControlApi.GetTokenRequest: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **grantType** | **string**| value &#x3D; implicit | 
 **clientId** | **string**| a valid  OAuth2 client id registered to the app authorized to use the API is required (this changes with each app store version iteration) | 
 **clientSecret** | **string**| the client secret associated to the app client id (this changes with each app store version iteration) | 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="posttokenrequest"></a>
# **PostTokenRequest**
> OAuthToken PostTokenRequest ()



Authorization Code grant types require a POST to the token endpoint after a GET for Authorization code.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostTokenRequestExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";
            // Configure OAuth2 access token for authorization: MobileApp_Implicit
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";
            // Configure OAuth2 access token for authorization: admin_AccessCode
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new AccessControlApi();

            try
            {
                OAuthToken result = apiInstance.PostTokenRequest();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AccessControlApi.PostTokenRequest: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

[AccessCode](../README.md#AccessCode), [MobileApp_Implicit](../README.md#MobileApp_Implicit), [admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

